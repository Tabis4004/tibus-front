import { supabase } from "@/lib/supabase";
import {
  formatTechnicalAnnexText,
  getDefaultTechnicalAnnex,
  normalizeTechnicalAnnexRpc,
  type CommercialOfferTechnicalAnnex,
} from "@/lib/commercial-offer-annex.ts";

export type CompanyOwnerContractStatus = {
  companyId: string;
  ownerContractAcceptedAt: string | null;
  liveAuthorizedByAdmin: boolean;
  liveAuthorizedAt: string | null;
  isActive: boolean;
  arretReservation: boolean;
  canEnableLive: boolean;
};

export async function getCommercialOfferTechnicalAnnexSupabase(
  countryId: string,
  locale: string,
): Promise<CommercialOfferTechnicalAnnex | null> {
  const { data, error } = await supabase.rpc("get_commercial_offer_technical_annex", {
    p_country_id: countryId,
    p_locale: locale,
  });
  if (error) throw error;
  return normalizeTechnicalAnnexRpc(data) ?? null;
}

export async function resolveTechnicalAnnexForCountry(
  countryId: string | null | undefined,
  locale: string,
): Promise<{ annex: CommercialOfferTechnicalAnnex; annexText: string }> {
  if (countryId) {
    try {
      const remote = await getCommercialOfferTechnicalAnnexSupabase(countryId, locale);
      if (remote) {
        return { annex: remote, annexText: formatTechnicalAnnexText(remote) };
      }
    } catch {
      // fallback to defaults
    }
  }
  const annex = getDefaultTechnicalAnnex(locale);
  return { annex, annexText: formatTechnicalAnnexText(annex) };
}

export async function getCompanyOwnerContractStatusSupabase(
  companyId: string,
): Promise<CompanyOwnerContractStatus> {
  const { data, error } = await supabase.rpc("get_company_owner_contract_status", {
    p_company_id: companyId,
  });
  if (error) throw error;
  const row = data as Record<string, unknown>;
  return {
    companyId,
    ownerContractAcceptedAt: row.ownerContractAcceptedAt
      ? String(row.ownerContractAcceptedAt)
      : null,
    liveAuthorizedByAdmin: Boolean(row.liveAuthorizedByAdmin),
    liveAuthorizedAt: row.liveAuthorizedAt ? String(row.liveAuthorizedAt) : null,
    isActive: Boolean(row.isActive),
    arretReservation: Boolean(row.arretReservation),
    canEnableLive: Boolean(row.canEnableLive),
  };
}

export async function acceptCompanyOwnerContractSupabase(companyId: string): Promise<void> {
  const { error } = await supabase.rpc("accept_company_owner_contract", {
    p_company_id: companyId,
  });
  if (error) throw error;
}

export async function setCompanyArretReservationSupabase(
  companyId: string,
  enabled: boolean,
): Promise<void> {
  const { error } = await supabase.rpc("set_company_arret_reservation", {
    p_company_id: companyId,
    p_enabled: enabled,
  });
  if (error) throw error;
}

export async function setCompanyLiveAuthorizationSupabase(
  companyId: string,
  authorized: boolean,
): Promise<void> {
  const { error } = await supabase.rpc("set_company_live_authorization", {
    p_company_id: companyId,
    p_authorized: authorized,
  });
  if (error) throw error;
}

export async function setCompanyActiveAdminSupabase(
  companyId: string,
  isActive: boolean,
): Promise<void> {
  const { error } = await supabase.rpc("set_company_active_admin", {
    p_company_id: companyId,
    p_is_active: isActive,
  });
  if (error) throw error;
}

// Suppression DÉFINITIVE d'une compagnie et de toutes ses données
// (super admin uniquement). La RPC exige le nom exact de la compagnie en
// confirmation. Action irréversible.
export async function adminDeleteCompanySupabase(
  companyId: string,
  confirmName: string,
): Promise<void> {
  const { error } = await supabase.rpc("admin_delete_company", {
    p_company_id: companyId,
    p_confirm_name: confirmName,
  });
  if (error) throw error;
}

export type WipeCompanyOperationsResult = {
  deletedColis: number;
  deletedReservations: number;
  deletedReservationBus: number;
  deletedBordereaux: number;
  deletedMouvementsCaisse: number;
  deletedReversements: number;
  resetCaisses: number;
};

// Remet une compagnie à zéro (ventes tickets, colis, bordereaux/manifests,
// historique de caisse) SANS supprimer la compagnie — super admin
// uniquement, nom exact requis en confirmation (migration 185). Action
// irréversible mais réutilisable (contrairement à adminDeleteCompanySupabase).
export async function wipeCompanyOperationsSupabase(
  companyId: string,
  confirmName: string,
): Promise<WipeCompanyOperationsResult> {
  const { data, error } = await supabase.rpc("wipe_company_operations", {
    p_company_id: companyId,
    p_confirm_name: confirmName,
  });
  if (error) throw error;
  const row = (data ?? {}) as Record<string, unknown>;
  return {
    deletedColis: Number(row.deletedColis ?? 0),
    deletedReservations: Number(row.deletedReservations ?? 0),
    deletedReservationBus: Number(row.deletedReservationBus ?? 0),
    deletedBordereaux: Number(row.deletedBordereaux ?? 0),
    deletedMouvementsCaisse: Number(row.deletedMouvementsCaisse ?? 0),
    deletedReversements: Number(row.deletedReversements ?? 0),
    resetCaisses: Number(row.resetCaisses ?? 0),
  };
}
