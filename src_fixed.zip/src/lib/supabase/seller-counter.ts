import { supabase } from "@/lib/supabase";
import { throwSupabaseError } from "@/lib/supabase/errors";
import type { SellerCompanyReceiptInfo } from "@/lib/ticket-receipt-print.ts";
import {
  searchTripsSupabase,
  type TripSearchResult,
} from "@/lib/supabase/trip-search";

export type SellerCompany = {
  id: string;
  name: string;
};

export type { SellerCompanyReceiptInfo };

export type SellerProfileSupabase = {
  user: {
    id: string;
    name: string;
    email: string | null;
  };
  company: SellerCompany | null;
  /** Toutes les compagnies où l'utilisateur a un rôle de vente (multi-compagnies). */
  companies: SellerCompany[];
  roleNames: string[];
  canSellDirect: boolean;
  canReserveWithGateway: boolean;
  canSellAllCompanies: boolean;
};

export type SellerCounterTrip = TripSearchResult & {
  companyId?: string;
};

export type CounterTravelerInput = {
  passengerName: string;
  passengerPhone?: string;
  seatNumber?: string;
  parcelCount?: number;
  parcelWeight?: number;
  parcelAmount?: number;
};

export type CounterSaleTicket = {
  bookingId: string;
  reference: string;
  verifyToken?: string | null;
  totalPrice: number;
  currency: string;
  passengerName: string;
  passengerPhone?: string;
  seatNumber?: string;
  parcelCount: number;
  parcelWeight: number;
  parcelAmount: number;
};

function roleNameFromJoin(
  role: { name: string } | { name: string }[] | null | undefined,
): string | null {
  if (!role) return null;
  if (Array.isArray(role)) return role[0]?.name ?? null;
  return role.name ?? null;
}

export async function getSellerProfileSupabase(
  appUserId: string,
  preferredCompanyId?: string | null,
): Promise<SellerProfileSupabase | null> {
  const { data: user, error: userError } = await supabase
    .from("Users")
    .select("id, firstName, lastName, email")
    .eq("id", appUserId)
    .maybeSingle();

  if (userError) throw userError;
  if (!user) return null;

  const { data: roles, error: rolesError } = await supabase
    .from("UserRoles")
    .select("companyId, gareId, Role(name)")
    .eq("userId", appUserId);

  if (rolesError) throw rolesError;

  const sellerRoles = (roles ?? []).filter((row) => {
    const name = roleNameFromJoin(
      row.Role as { name: string } | { name: string }[] | null,
    );
    return [
      "super_admin",
      "vendeur",
      "vendeur_gare",
      "chauffeur",
      "vendeur_independant",
      "vendeur_reseau",
      "vendeur_master",
      "owner",
    ].includes(name ?? "");
  });

  if (!sellerRoles.length) return null;

  const roleNames = sellerRoles
    .map((row) => roleNameFromJoin(row.Role as { name: string } | { name: string }[] | null))
    .filter((name): name is string => Boolean(name));

  const companySellerRow = sellerRoles.find((row) => {
    const name = roleNameFromJoin(row.Role as { name: string } | { name: string }[] | null);
    return Boolean(row.companyId) && (name === "vendeur" || name === "vendeur_gare" || name === "chauffeur" || name === "owner");
  });

  const gareSellerRow = sellerRoles.find((row) => {
    const name = roleNameFromJoin(row.Role as { name: string } | { name: string }[] | null);
    return name === "vendeur_gare" && Boolean(row.gareId);
  });

  // Toutes les compagnies où l'utilisateur peut vendre (un vendeur peut être
  // rattaché à plusieurs compagnies) — rôles directs + rattachement via gare.
  const companyIdSet = new Set<string>(
    sellerRoles
      .map((row) => row.companyId as string | null)
      .filter((id): id is string => Boolean(id)),
  );

  if (gareSellerRow?.gareId && !gareSellerRow.companyId) {
    const { data: gareRow, error: gareError } = await supabase
      .from("Gares")
      .select("companyId")
      .eq("id", gareSellerRow.gareId as string)
      .maybeSingle();
    if (gareError) throw gareError;
    const gareCompanyId = gareRow?.companyId as string | undefined;
    if (gareCompanyId) companyIdSet.add(gareCompanyId);
  }

  let companies: SellerCompany[] = [];
  if (companyIdSet.size) {
    const { data: companyRows, error: companiesError } = await supabase
      .from("Companies")
      .select("id, name")
      .in("id", [...companyIdSet])
      .order("name");
    if (companiesError) throw companiesError;
    companies = (companyRows ?? []).map((row) => ({
      id: row.id as string,
      name: row.name as string,
    }));
  }

  // Compagnie active : préférence explicite (sélecteur du dashboard) si elle
  // fait partie des compagnies du vendeur, sinon comportement historique.
  let companyId =
    preferredCompanyId && companyIdSet.has(preferredCompanyId)
      ? preferredCompanyId
      : ((companySellerRow?.companyId ?? sellerRoles.find((row) => row.companyId)?.companyId) as
          | string
          | undefined) ?? [...companyIdSet][0];

  const company: SellerCompany | null =
    companies.find((row) => row.id === companyId) ?? null;
  companyId = company?.id ?? companyId;

  const canSellDirect = Boolean(companySellerRow || gareSellerRow);
  const canReserveWithGateway = roleNames.some((name) =>
    ["vendeur_independant", "vendeur_reseau", "vendeur_master"].includes(name),
  );
  const canSellAllCompanies = roleNames.some((name) =>
    ["super_admin", "vendeur_independant", "vendeur_reseau", "vendeur_master"].includes(name),
  );

  return {
    user: {
      id: user.id as string,
      name: `${user.firstName ?? ""} ${user.lastName ?? ""}`.trim(),
      email: user.email as string | null,
    },
    company,
    companies,
    roleNames,
    canSellDirect,
    canReserveWithGateway,
    canSellAllCompanies,
  };
}

export async function getSellerCompanyReceiptInfoSupabase(
  companyId: string,
): Promise<SellerCompanyReceiptInfo | null> {
  const id = companyId?.trim();
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return null;

  const { data, error } = await supabase
    .from("Companies")
    .select("name, logo, managerName, voyageColisMsg")
    .eq("id", id)
    .maybeSingle();

  if (error) throw error;
  if (!data) return null;

  return {
    name: data.name as string,
    logoUrl: (data.logo as string | null) ?? null,
    boardingMessage: (data.voyageColisMsg as string | null) ?? undefined,
  };
}

export async function listSellerTripsSupabase(
  profile: SellerProfileSupabase,
  options?: { departureGareId?: string },
): Promise<SellerCounterTrip[]> {
  const trips = await searchTripsSupabase({
    ...(profile.company && !profile.canSellAllCompanies
      ? { companyId: profile.company.id }
      : {}),
    ...(options?.departureGareId ? { departureGareId: options.departureGareId } : {}),
  });

  return trips
    .filter((trip) => trip.seatsAvailable > 0)
    .map((trip) => ({
      ...trip,
      companyId: trip.companyId ?? profile.company?.id,
    }));
}

export async function sellCounterTicketSupabase(input: {
  reservationId: string;
  traveler: CounterTravelerInput;
  clientMutationId?: string;
}): Promise<CounterSaleTicket> {
  const traveler = input.traveler;
  const rpcPayload = {
    p_reservation_id: input.reservationId,
    p_passenger_name: traveler.passengerName.trim(),
    p_passenger_phone: traveler.passengerPhone?.trim() || null,
    p_seat_number: traveler.seatNumber?.trim() || null,
    p_parcel_count: traveler.parcelCount ?? 0,
    p_parcel_weight: traveler.parcelWeight ?? 0,
    p_parcel_amount: traveler.parcelAmount ?? 0,
  };

  if (input.clientMutationId) {
    const { data, error } = await supabase.rpc("seller_counter_sale_idempotent", {
      p_client_mutation_id: input.clientMutationId,
      ...rpcPayload,
    });

    if (!error && data) {
      const row = typeof data === "string" ? JSON.parse(data) : data;
      const payload = row as Record<string, unknown>;
      return {
        bookingId: String(payload.booking_id),
        reference: String(payload.reference),
        verifyToken: (payload.verify_token as string | null) ?? null,
        totalPrice: Number(payload.total_price),
        currency: String(payload.currency),
        passengerName: traveler.passengerName.trim(),
        passengerPhone: traveler.passengerPhone?.trim() || undefined,
        seatNumber: traveler.seatNumber?.trim() || undefined,
        parcelCount: traveler.parcelCount ?? 0,
        parcelWeight: traveler.parcelWeight ?? 0,
        parcelAmount: traveler.parcelAmount ?? 0,
      };
    }

    const missingIdempotentRpc =
      error &&
      /seller_counter_sale_idempotent|could not find the function|PGRST202/i.test(error.message);
    if (!missingIdempotentRpc) {
      throwSupabaseError(error, "Vente guichet impossible");
    }
  }

  const { data, error } = await supabase.rpc("seller_counter_sale", rpcPayload);

  if (error) throwSupabaseError(error, "Vente guichet impossible");

  const row = Array.isArray(data) ? data[0] : data;
  if (!row) throw new Error("Ticket non cree");

  return {
    bookingId: row.booking_id as string,
    reference: row.reference as string,
    verifyToken: (row.verify_token as string | null) ?? null,
    totalPrice: row.total_price as number,
    currency: row.currency as string,
    passengerName: traveler.passengerName.trim(),
    passengerPhone: traveler.passengerPhone?.trim() || undefined,
    seatNumber: traveler.seatNumber?.trim() || undefined,
    parcelCount: traveler.parcelCount ?? 0,
    parcelWeight: traveler.parcelWeight ?? 0,
    parcelAmount: traveler.parcelAmount ?? 0,
  };
}
