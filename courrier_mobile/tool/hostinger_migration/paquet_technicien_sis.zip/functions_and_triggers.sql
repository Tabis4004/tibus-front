-- ==== FUNCTION _assert_bordereau_access ====
CREATE OR REPLACE FUNCTION public._assert_bordereau_access(p_company_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_user uuid := public.current_app_user_id();
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT (public.is_company_role_user(v_user, p_company_id) OR public.is_super_admin()) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;
  IF NOT public.company_colis_module_enabled(p_company_id) THEN
    RAISE EXCEPTION 'Module colis autonome non active';
  END IF;
END;
$function$
;

-- ==== FUNCTION _assert_lot_access ====
CREATE OR REPLACE FUNCTION public._assert_lot_access(p_company_id uuid, p_gare_id uuid, p_roles text[])
 RETURNS void
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  IF public.current_app_user_id() IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.company_colis_module_enabled(p_company_id) THEN
    RAISE EXCEPTION 'Module colis autonome non active';
  END IF;
  IF public.is_super_admin() THEN RETURN; END IF;
  IF public.has_company_role(p_company_id, ARRAY['owner','comptable_compagnie']) THEN RETURN; END IF;
  -- Rôle opérationnel (emballeur_gare/chargeur_gare/distributeur_gare)
  -- attribué SANS gare (rôle global compagnie, nouveau schéma) : agit sur
  -- toutes les gares de la compagnie.
  IF public.has_company_role(p_company_id, p_roles) THEN RETURN; END IF;
  -- Rétrocompatibilité : rôle attribué à CETTE gare précise (ancien schéma),
  -- ou gérant de cette gare.
  IF public.has_gare_role(p_gare_id, array_append(p_roles, 'gerant_gare')) THEN RETURN; END IF;
  RAISE EXCEPTION 'Droits insuffisants pour cette action (role gare requis : %)', array_to_string(p_roles, ', ');
END;
$function$
;

-- ==== FUNCTION _colis_gare_breakdown_access ====
CREATE OR REPLACE FUNCTION public._colis_gare_breakdown_access(p_user_id uuid, p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT public.is_super_admin()
    OR public.has_company_role(p_company_id, ARRAY['owner'])
    OR EXISTS (
      SELECT 1 FROM "UserRoles" ur
      JOIN "Role" r ON r.id = ur."roleId"
      JOIN "Users" u ON u.id = ur."userId"
      JOIN "Companies" c ON c."countryId" = ur."countryId"
      WHERE u."auth_user_id" = auth.uid()
        AND c.id = p_company_id
        AND r.name = 'admin_pays'
    );
$function$
;

-- ==== FUNCTION _colis_notification_recipients ====
CREATE OR REPLACE FUNCTION public._colis_notification_recipients(p_company_id uuid, p_gare_depart_id uuid, p_gare_destination_id uuid DEFAULT NULL::uuid, p_exclude_user_id uuid DEFAULT NULL::uuid)
 RETURNS uuid[]
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT COALESCE(array_agg(DISTINCT ur."userId"), ARRAY[]::uuid[])
  FROM "UserRoles" ur
  JOIN "Role" r ON r.id = ur."roleId"
  WHERE ur."companyId" = p_company_id
    AND (
      r.name IN ('owner', 'comptable_compagnie')
      OR (
        r.name IN ('gerant_gare', 'gestionnaire_gare')
        AND ur."gareId" IN (p_gare_depart_id, COALESCE(p_gare_destination_id, p_gare_depart_id))
      )
    )
    AND (p_exclude_user_id IS NULL OR ur."userId" <> p_exclude_user_id);
$function$
;

-- ==== FUNCTION _colis_stats_full_access ====
CREATE OR REPLACE FUNCTION public._colis_stats_full_access(p_user_id uuid, p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT public.is_super_admin() OR EXISTS (
    SELECT 1
    FROM "UserRoles" ur
    JOIN "Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = p_user_id
      AND ur."companyId" = p_company_id
      AND r.name IN ('owner', 'comptable_compagnie')
  );
$function$
;

-- ==== FUNCTION _colis_stats_gerant_gares ====
CREATE OR REPLACE FUNCTION public._colis_stats_gerant_gares(p_user_id uuid, p_company_id uuid)
 RETURNS uuid[]
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT array_agg(DISTINCT ur."gareId")
  FROM "UserRoles" ur
  JOIN "Role" r ON r.id = ur."roleId"
  WHERE ur."userId" = p_user_id
    AND ur."companyId" = p_company_id
    AND ur."gareId" IS NOT NULL
    AND r.name IN ('gerant_gare', 'gestionnaire_gare');
$function$
;

-- ==== FUNCTION _company_module_flag ====
CREATE OR REPLACE FUNCTION public._company_module_flag(p_row "CompanyFeatureModules", p_module text)
 RETURNS boolean
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  RETURN CASE upper(trim(p_module))
    WHEN 'A' THEN p_row."moduleA"
    WHEN 'B' THEN p_row."moduleB"
    WHEN 'C' THEN p_row."moduleC"
    WHEN 'D' THEN p_row."moduleD"
    WHEN 'E' THEN p_row."moduleE"
    WHEN 'F' THEN p_row."moduleF"
    ELSE false
  END;
END;
$function$
;

-- ==== FUNCTION _create_colis_notifications ====
CREATE OR REPLACE FUNCTION public._create_colis_notifications(p_user_ids uuid[], p_type text, p_title text, p_message text, p_metadata jsonb DEFAULT '{}'::jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF p_user_ids IS NULL OR array_length(p_user_ids, 1) IS NULL THEN RETURN; END IF;
  INSERT INTO "Notifications" ("userId", type, title, message, "isRead", metadata)
  SELECT uid, p_type, p_title, p_message, false, p_metadata
  FROM unnest(p_user_ids) AS uid;
END;
$function$
;

-- ==== FUNCTION _is_gare_scoped_role ====
CREATE OR REPLACE FUNCTION public._is_gare_scoped_role(p_role_name text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE
AS $function$
  -- emballeur_gare / chargeur_gare / distributeur_gare sont devenus des
  -- rôles compagnie GLOBAUX (plus rattachés a une seule gare) — voir
  -- owner-team-roles.ts, commentaire "migration 193". Ils restent nommés
  -- avec le suffixe "_gare" pour raisons historiques mais ne doivent plus
  -- exiger de gareId ici.
  SELECT p_role_name IN (
    'gerant_gare', 'gestionnaire_gare', 'vendeur_gare', 'controleur_gare', 'comptable_gare'
  );
$function$
;

-- ==== FUNCTION _owner_company_id ====
CREATE OR REPLACE FUNCTION public._owner_company_id()
 RETURNS uuid
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_company_id uuid;
BEGIN
  SELECT ur."companyId"
  INTO v_company_id
  FROM "UserRoles" ur
  JOIN "Role" r ON r.id = ur."roleId"
  WHERE ur."userId" = public.current_app_user_id()
    AND r.name = 'owner'
    AND ur."companyId" IS NOT NULL
  LIMIT 1;
  RETURN v_company_id;
END;
$function$
;

-- ==== FUNCTION _seed_company_colis_natures ====
CREATE OR REPLACE FUNCTION public._seed_company_colis_natures(p_company_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_libelle text;
BEGIN
  IF p_company_id IS NULL THEN
    RETURN;
  END IF;

  FOR v_libelle IN
    SELECT * FROM (VALUES
      ('Enveloppe'),
      ('Sac de jute'),
      ('Carton'),
      ('Valise'),
      ('Bidon')
    ) AS t(libelle)
  LOOP
    INSERT INTO colis_natures (company_id, libelle, is_active)
    VALUES (p_company_id, v_libelle, true)
    ON CONFLICT (company_id, libelle) DO NOTHING;
  END LOOP;
END;
$function$
;

-- ==== FUNCTION _seed_company_expense_categories ====
CREATE OR REPLACE FUNCTION public._seed_company_expense_categories(p_company_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_preset record;
BEGIN
  IF p_company_id IS NULL THEN
    RETURN;
  END IF;

  FOR v_preset IN
    SELECT *
    FROM (
      VALUES
        (10,  'Carburant',                      '6047', 'Achats de carburants et lubrifiants', true),
        (20,  'Réparations',                    '6156', 'Entretien, réparations et maintenance', true),
        (30,  'Pièces détachées',              '6042', 'Achats de pièces et fournitures consommables', true),
        (40,  'Salaires équipe',                '6412', 'Salaires, appointements et commissions du personnel', true),
        (50,  'Électricité',                    '6052', 'Eau et électricité', true),
        (60,  'Communication',                  '6241', 'Frais de téléphone et communication', true),
        (70,  'Internet',                       '6248', 'Frais d''Internet', true),
        (80,  'Achat de matériel de bureau',    '6045', 'Achats de matériel et fournitures de bureau', true),
        (90,  'Marketing',                      '6228', 'Publicité, publications et relations publiques', true),
        (100, 'Abonnement TV',                  '6288', 'Abonnements et services (TV, médias)', true),
        (110, 'Transports interne',             '6135', 'Transports internes et déplacements exploitation', true)
    ) AS t(sort_order, name, ohada_code, ohada_label, is_preset)
  LOOP
    INSERT INTO "CompanyExpenseCategory" (
      "companyId",
      name,
      "ohadaAccountCode",
      "ohadaAccountLabel",
      "sortOrder",
      "isPreset"
    )
    VALUES (
      p_company_id,
      v_preset.name,
      v_preset.ohada_code,
      v_preset.ohada_label,
      v_preset.sort_order,
      v_preset.is_preset
    )
    ON CONFLICT ("companyId", name) DO NOTHING;
  END LOOP;
END;
$function$
;

-- ==== FUNCTION add_colis_to_bordereau ====
CREATE OR REPLACE FUNCTION public.add_colis_to_bordereau(p_bordereau_id uuid, p_colis_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_bl bordereaux_livraison%ROWTYPE;
  v_colis colis_autonomes%ROWTYPE;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  PERFORM public._assert_lot_access_ville(v_bl.company_id, v_bl.ville_depart_id, ARRAY['emballeur_gare','chargeur_gare']);
  IF v_bl.statut <> 'ouvert' THEN RAISE EXCEPTION 'Lot cloture'; END IF;

  SELECT * INTO v_colis FROM colis_autonomes WHERE id = p_colis_id;
  IF v_colis.id IS NULL THEN RAISE EXCEPTION 'Colis introuvable'; END IF;
  IF v_colis.company_id <> v_bl.company_id THEN
    RAISE EXCEPTION 'Colis d''une autre compagnie';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM "Gares" g WHERE g.id = v_colis.gare_depart_id AND g."cityId" = v_bl.ville_depart_id
  ) THEN
    RAISE EXCEPTION 'Ce colis ne part pas de la ville de depart de ce lot';
  END IF;
  IF v_bl.gare_destination_id IS NOT NULL AND v_colis.gare_destination_id <> v_bl.gare_destination_id THEN
    RAISE EXCEPTION 'Ce colis n''a pas la meme destination que ce lot';
  END IF;
  IF v_colis.statut_colis <> 'enregistre' THEN
    RAISE EXCEPTION 'Seuls les colis enregistres (pas encore charges) peuvent etre emballes dans un lot';
  END IF;
  IF EXISTS (
    SELECT 1 FROM bordereau_colis bc WHERE bc.bordereau_id = p_bordereau_id AND bc.colis_id = p_colis_id
  ) THEN
    RAISE EXCEPTION 'Colis deja sur ce lot';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM bordereau_colis bc
    JOIN bordereaux_livraison bl ON bl.id = bc.bordereau_id
    WHERE bc.colis_id = p_colis_id AND bl.statut IN ('ouvert', 'clos', 'charge')
  ) THEN
    RAISE EXCEPTION 'Colis deja affecte a un autre lot en cours';
  END IF;

  INSERT INTO bordereau_colis (bordereau_id, colis_id) VALUES (p_bordereau_id, p_colis_id);

  RETURN jsonb_build_object('id', v_colis.id, 'statutColis', v_colis.statut_colis);
END;
$function$
;

-- ==== FUNCTION assert_company_module ====
CREATE OR REPLACE FUNCTION public.assert_company_module(p_company_id uuid, p_module text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF public.is_super_admin() THEN
    RETURN;
  END IF;

  IF NOT public.company_has_module(p_company_id, p_module) THEN
    RAISE EXCEPTION 'Module % non activé pour cette compagnie', upper(trim(p_module));
  END IF;
END;
$function$
;

-- ==== FUNCTION assert_seller_cash_departure_gare ====
CREATE OR REPLACE FUNCTION public.assert_seller_cash_departure_gare(p_caisse_id uuid, p_depart_gare_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_caisse_gare_id uuid;
BEGIN
  SELECT c.gare_id INTO v_caisse_gare_id
  FROM caisses_gares c
  WHERE c.id = p_caisse_id;
  IF v_caisse_gare_id IS NULL THEN
    RAISE EXCEPTION 'Caisse introuvable';
  END IF;
  IF p_depart_gare_id IS DISTINCT FROM v_caisse_gare_id THEN
    RAISE EXCEPTION 'Vente cash reservee aux departs de votre gare ouverte. Pour une autre gare, utilisez la reservation en ligne.';
  END IF;
END;
$function$
;

-- ==== FUNCTION assign_colis_numero_recu ====
CREATE OR REPLACE FUNCTION public.assign_colis_numero_recu()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE v_seq integer;
BEGIN
  IF NEW.numero_recu IS NOT NULL THEN RETURN NEW; END IF;
  -- Upsert atomique : le verrou de ligne sérialise les insertions
  -- concurrentes d'une même gare.
  INSERT INTO colis_numerotation_gares (gare_id, last_seq)
  VALUES (NEW.gare_depart_id, 1)
  ON CONFLICT (gare_id) DO UPDATE SET last_seq = colis_numerotation_gares.last_seq + 1
  RETURNING last_seq INTO v_seq;
  NEW.numero_recu := public.colis_gare_prefix(NEW.gare_depart_id) || lpad(v_seq::text, 6, '0');
  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION build_colis_sms_message ====
CREATE OR REPLACE FUNCTION public.build_colis_sms_message(p_statut text, p_colis_id uuid, p_company_name text, p_gare_depart text, p_gare_destination text)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_ref text := public.colis_public_reference_sql(p_colis_id);
BEGIN
  RETURN CASE p_statut
    WHEN 'enregistre' THEN format(
      'Tibus/%s: colis enregistre. Ref %s. %s -> %s.',
      COALESCE(p_company_name, 'Compagnie'), v_ref,
      COALESCE(p_gare_depart, '?'), COALESCE(p_gare_destination, '?')
    )
    WHEN 'charge' THEN format(
      'Tibus/%s: votre colis est charge en soute (%s -> %s). Ref %s.',
      COALESCE(p_company_name, 'Compagnie'),
      COALESCE(p_gare_depart, '?'), COALESCE(p_gare_destination, '?'), v_ref
    )
    WHEN 'arrive' THEN format(
      'Tibus/%s: colis arrive a %s. Ref retrait %s.',
      COALESCE(p_company_name, 'Compagnie'), COALESCE(p_gare_destination, 'gare'), v_ref
    )
    WHEN 'livre' THEN format(
      'Tibus/%s: colis remis au destinataire. Ref %s. Merci.',
      COALESCE(p_company_name, 'Compagnie'), v_ref
    )
    ELSE NULL
  END;
END;
$function$
;

-- ==== FUNCTION build_colis_sms_payload ====
CREATE OR REPLACE FUNCTION public.build_colis_sms_payload(p_company_id uuid, p_statut text, p_message text, p_expediteur_phone text, p_destinataire_phone text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_send boolean;
  v_admin_gate boolean;
BEGIN
  v_admin_gate := public.company_colis_sms_owner_config_enabled(p_company_id);
  v_send := public.colis_sms_enabled_for_statut(p_company_id, p_statut);

  RETURN jsonb_build_object(
    'send', v_send,
    'message', CASE WHEN v_send THEN p_message ELSE NULL END,
    'expediteurPhone', NULLIF(btrim(p_expediteur_phone), ''),
    'destinatairePhone', NULLIF(btrim(p_destinataire_phone), ''),
    'skipReason', CASE
      WHEN v_send THEN NULL
      WHEN NOT v_admin_gate THEN 'admin_gate'
      ELSE 'owner_disabled'
    END
  );
END;
$function$
;

-- ==== FUNCTION can_operate_station_cash ====
CREATE OR REPLACE FUNCTION public.can_operate_station_cash(p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT public.is_super_admin()
    OR EXISTS (
      SELECT 1
      FROM public."UserRoles" ur
      JOIN public."Role" r ON r.id = ur."roleId"
      WHERE ur."userId" = public.current_app_user_id()
        AND ur."companyId" = p_company_id
        AND r.name IN ('owner', 'vendeur', 'vendeur_gare', 'chauffeur')
    );
$function$
;

-- ==== FUNCTION can_validate_station_reversal ====
CREATE OR REPLACE FUNCTION public.can_validate_station_reversal(p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT public.is_super_admin()
    OR public.has_company_role(p_company_id, ARRAY['owner', 'comptable_compagnie'])
    OR EXISTS (
      SELECT 1
      FROM public."UserRoles" ur
      JOIN public."Role" r ON r.id = ur."roleId"
      WHERE ur."userId" = public.current_app_user_id()
        AND ur."companyId" = p_company_id
        AND ur."gareId" IS NOT NULL
        AND r.name IN ('comptable_gare', 'gerant_gare')
    );
$function$
;

-- ==== FUNCTION close_bordereau_livraison ====
CREATE OR REPLACE FUNCTION public.close_bordereau_livraison(p_bordereau_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_bl bordereaux_livraison%ROWTYPE;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  PERFORM public._assert_lot_access_ville(v_bl.company_id, v_bl.ville_depart_id, ARRAY['emballeur_gare','chargeur_gare']);
  IF NOT EXISTS (SELECT 1 FROM bordereau_colis WHERE bordereau_id = p_bordereau_id) THEN
    RAISE EXCEPTION 'Le lot est vide — scannez au moins un colis avant de cloturer';
  END IF;
  UPDATE bordereaux_livraison
  SET statut = 'clos', closed_at = now()
  WHERE id = p_bordereau_id AND statut = 'ouvert';
  RETURN public.get_bordereau_livraison(p_bordereau_id);
END;
$function$
;

-- ==== FUNCTION close_station_cash_register ====
CREATE OR REPLACE FUNCTION public.close_station_cash_register(p_caisse_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
  v_caisse record;
  v_company_id uuid;
BEGIN
  v_user_id := public.current_app_user_id();
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Utilisateur introuvable'; END IF;

  SELECT * INTO v_caisse FROM public.caisses_gares WHERE id = p_caisse_id FOR UPDATE;
  IF v_caisse.id IS NULL THEN RAISE EXCEPTION 'Caisse introuvable'; END IF;

  IF v_caisse.statut <> 'ouverte' THEN
    RAISE EXCEPTION 'Session deja cloturee';
  END IF;

  v_company_id := public.station_cash_gare_company_id(v_caisse.gare_id);

  IF NOT (
    v_caisse.gestionnaire_id = v_user_id
    OR public.is_super_admin()
    OR public.has_company_role(v_company_id, ARRAY['owner', 'comptable_compagnie'])
    OR public.has_gare_role(v_caisse.gare_id, ARRAY['comptable_gare', 'gerant_gare', 'gestionnaire_gare'])
  ) THEN
    RAISE EXCEPTION 'Cloture reservee au vendeur de la session, au comptable ou a l''owner';
  END IF;

  UPDATE public.caisses_gares
  SET statut = 'cloturee', closed_at = now(), solde_especes_actuel = 0
  WHERE id = p_caisse_id;

  RETURN jsonb_build_object(
    'id', p_caisse_id,
    'status', 'cloturee',
    'closedAt', now(),
    'balance', 0
  );
END;
$function$
;

-- ==== FUNCTION colis_gare_prefix ====
CREATE OR REPLACE FUNCTION public.colis_gare_prefix(p_gare_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE v_prefix text;
BEGIN
  SELECT left(regexp_replace(
    upper(translate(coalesce(g.name, ''),
      'ÀÂÄÁÃÉÈÊËÍÎÏÓÔÖÕÚÙÛÜÇÑàâäáãéèêëíîïóôöõúùûüçñ',
      'AAAAAEEEEIIIOOOOUUUUCNaaaaaeeeeiiioooouuuucn')),
    '[^A-Z0-9]', '', 'g'), 4)
  INTO v_prefix
  FROM "Gares" g WHERE g.id = p_gare_id;
  RETURN COALESCE(NULLIF(v_prefix, ''), 'GARE');
END;
$function$
;

-- ==== FUNCTION colis_public_reference_sql ====
CREATE OR REPLACE FUNCTION public.colis_public_reference_sql(p_colis_id uuid)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT 'CL-' || upper(substr(replace(p_colis_id::text, '-', ''), 1, 8));
$function$
;

-- ==== FUNCTION colis_sms_enabled_for_statut ====
CREATE OR REPLACE FUNCTION public.colis_sms_enabled_for_statut(p_company_id uuid, p_statut text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT COALESCE(public.company_colis_sms_step_allowed(p_company_id, p_statut), false)
    AND CASE p_statut
      WHEN 'enregistre' THEN COALESCE(c.sms_on_enregistre, false)
      WHEN 'charge' THEN COALESCE(c.sms_on_charge, false)
      WHEN 'arrive' THEN COALESCE(c.sms_on_arrive, false)
      WHEN 'livre' THEN COALESCE(c.sms_on_livre, false)
      ELSE false
    END
  FROM public."Companies" c
  WHERE c.id = p_company_id;
$function$
;

-- ==== FUNCTION company_colis_module_enabled ====
CREATE OR REPLACE FUNCTION public.company_colis_module_enabled(p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT COALESCE(
    (SELECT m."moduleD" FROM "CompanyFeatureModules" m WHERE m."companyId" = p_company_id),
    -- Pas de ligne modules : mêmes défauts que get_company_feature_modules
    -- (module D actif par défaut).
    true
  )
  OR COALESCE(
    (SELECT c.colis_autonome_enabled FROM "Companies" c WHERE c.id = p_company_id),
    false
  );
$function$
;

-- ==== FUNCTION company_colis_sms_owner_config_enabled ====
CREATE OR REPLACE FUNCTION public.company_colis_sms_owner_config_enabled(p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT COALESCE(m."moduleD", false)
    AND COALESCE(m."moduleDColisSmsConfig", false)
  FROM public."CompanyFeatureModules" m
  WHERE m."companyId" = p_company_id;
$function$
;

-- ==== FUNCTION company_colis_sms_step_allowed ====
CREATE OR REPLACE FUNCTION public.company_colis_sms_step_allowed(p_company_id uuid, p_statut text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT COALESCE(m."moduleD", false)
    AND COALESCE(m."moduleDColisSmsConfig", false)
    AND CASE p_statut
      WHEN 'enregistre' THEN COALESCE(m."smsEnregistreAllowed", false)
      WHEN 'charge' THEN COALESCE(m."smsChargeAllowed", false)
      WHEN 'arrive' THEN COALESCE(m."smsArriveAllowed", false)
      WHEN 'livre' THEN COALESCE(m."smsLivreAllowed", false)
      ELSE false
    END
  FROM public."CompanyFeatureModules" m
  WHERE m."companyId" = p_company_id;
$function$
;

-- ==== FUNCTION company_has_module ====
CREATE OR REPLACE FUNCTION public.company_has_module(p_company_id uuid, p_module text)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_row public."CompanyFeatureModules"%ROWTYPE;
  v_enabled boolean;
  v_module text := upper(trim(p_module));
BEGIN
  IF p_company_id IS NULL OR v_module = '' THEN
    RETURN false;
  END IF;

  SELECT * INTO v_row
  FROM public."CompanyFeatureModules"
  WHERE "companyId" = p_company_id;

  IF NOT FOUND THEN
  -- Rétrocompatibilité : compagnies sans ligne = pack quasi complet hors TPE.
    RETURN v_module <> 'F';
  END IF;

  v_enabled := public._company_module_flag(v_row, v_module);
  IF NOT v_enabled THEN
    RETURN false;
  END IF;

  IF v_module IN ('B', 'C', 'E') AND NOT (v_row."moduleA" OR v_row."moduleD") THEN
    RETURN false;
  END IF;

  RETURN true;
END;
$function$
;

-- ==== FUNCTION compute_colis_prix_min ====
CREATE OR REPLACE FUNCTION public.compute_colis_prix_min(p_company_id uuid, p_nature_ids uuid[], p_poids_kg double precision)
 RETURNS double precision
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_general_fixe double precision;
  v_general_taux double precision;
  v_min double precision := 0;
  v_nature_min double precision;
  v_row record;
BEGIN
  SELECT colis_prix_min_fixe_general, colis_prix_min_taux_general
    INTO v_general_fixe, v_general_taux
  FROM "Companies" WHERE id = p_company_id;

  IF v_general_fixe IS NOT NULL THEN
    RETURN GREATEST(v_general_fixe, 0);
  END IF;
  IF v_general_taux IS NOT NULL THEN
    RETURN GREATEST(v_general_taux * COALESCE(p_poids_kg, 0), 0);
  END IF;

  IF p_nature_ids IS NULL OR array_length(p_nature_ids, 1) IS NULL THEN
    RETURN 0;
  END IF;

  FOR v_row IN
    SELECT prix_min_fixe, prix_min_taux
    FROM public.colis_natures
    WHERE id = ANY(p_nature_ids) AND company_id = p_company_id
  LOOP
    IF v_row.prix_min_fixe IS NOT NULL THEN
      v_nature_min := v_row.prix_min_fixe;
    ELSIF v_row.prix_min_taux IS NOT NULL THEN
      v_nature_min := v_row.prix_min_taux * COALESCE(p_poids_kg, 0);
    ELSE
      v_nature_min := 0;
    END IF;
    v_min := GREATEST(v_min, v_nature_min);
  END LOOP;

  RETURN GREATEST(v_min, 0);
END;
$function$
;

-- ==== FUNCTION count_unread_my_notifications ====
CREATE OR REPLACE FUNCTION public.count_unread_my_notifications()
 RETURNS integer
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT COUNT(*)::integer FROM "Notifications"
  WHERE "userId" = public.current_app_user_id() AND "isRead" = false;
$function$
;

-- ==== FUNCTION create_bordereau_livraison ====
CREATE OR REPLACE FUNCTION public.create_bordereau_livraison(p_company_id uuid, p_ville_depart_id uuid, p_gare_destination_id uuid DEFAULT NULL::uuid, p_bus_id uuid DEFAULT NULL::uuid, p_date_lot date DEFAULT NULL::date)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_id uuid;
  v_ref text;
BEGIN
  PERFORM public._assert_lot_access_ville(p_company_id, p_ville_depart_id, ARRAY['emballeur_gare','chargeur_gare']);

  IF p_gare_destination_id IS NULL THEN
    RAISE EXCEPTION 'La gare de destination est obligatoire pour creer un lot (regroupement par destination)';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM "Gares" g WHERE g."cityId" = p_ville_depart_id AND g."companyId" = p_company_id
  ) THEN
    RAISE EXCEPTION 'Ville de depart invalide pour cette compagnie (aucune gare de cette compagnie dans cette ville)';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM "Gares" g WHERE g.id = p_gare_destination_id AND g."companyId" = p_company_id
  ) THEN
    RAISE EXCEPTION 'Gare de destination invalide pour cette compagnie';
  END IF;
  IF p_bus_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM "Bus" b WHERE b.id = p_bus_id AND b."companyId" = p_company_id
  ) THEN
    RAISE EXCEPTION 'Bus invalide pour cette compagnie';
  END IF;

  v_ref := 'BL-' || upper(substring(replace(gen_random_uuid()::text, '-', '') FROM 1 FOR 8));

  INSERT INTO bordereaux_livraison (
    reference, company_id, ville_depart_id, gare_destination_id, bus_id, created_by, date_lot
  ) VALUES (
    v_ref, p_company_id, p_ville_depart_id, p_gare_destination_id, p_bus_id,
    public.current_app_user_id(), COALESCE(p_date_lot, CURRENT_DATE)
  ) RETURNING id INTO v_id;

  RETURN public.get_bordereau_livraison(v_id);
END;
$function$
;

-- ==== FUNCTION current_app_user_id ====
CREATE OR REPLACE FUNCTION public.current_app_user_id()
 RETURNS uuid
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT u.id
  FROM "Users" u
  WHERE u."auth_user_id" = auth.uid()
  LIMIT 1;
$function$
;

-- ==== FUNCTION deliver_colis_autonome ====
CREATE OR REPLACE FUNCTION public.deliver_colis_autonome(p_retrait_code text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_colis_id uuid;
  v_colis public.colis_autonomes%ROWTYPE;
  v_result jsonb;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Connexion requise';
  END IF;

  v_colis_id := public.resolve_colis_retrait_code(p_retrait_code);
  IF v_colis_id IS NULL THEN
    RAISE EXCEPTION 'Code de retrait invalide';
  END IF;

  SELECT * INTO v_colis FROM public.colis_autonomes WHERE id = v_colis_id;
  IF v_colis.id IS NULL THEN
    RAISE EXCEPTION 'Code de retrait invalide';
  END IF;

  IF NOT public.is_company_role_user(v_user_id, v_colis.company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  IF v_colis.statut_colis <> 'arrive' THEN
    RAISE EXCEPTION 'Colis non disponible (statut: %)', v_colis.statut_colis;
  END IF;

  v_result := public.update_colis_autonome_statut(v_colis.id, 'livre');
  RETURN v_result || jsonb_build_object(
    'nomDestinataire', v_colis.nom_destinataire,
    'nomExpediteur', v_colis.nom_expediteur
  );
END;
$function$
;

-- ==== FUNCTION enforce_single_admin_pays_per_country ====
CREATE OR REPLACE FUNCTION public.enforce_single_admin_pays_per_country()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_role_name text;
  v_holder record;
BEGIN
  SELECT r.name INTO v_role_name
  FROM public."Role" r
  WHERE r.id = NEW."roleId";

  IF v_role_name IS DISTINCT FROM 'admin_pays' OR NEW."countryId" IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT h.user_id, h.full_name, h.email
  INTO v_holder
  FROM public.get_country_admin_pays_holder(NEW."countryId", NEW."userId") h
  LIMIT 1;

  IF v_holder.user_id IS NOT NULL THEN
    RAISE EXCEPTION
      'ADMIN_PAYS_COUNTRY_TAKEN|%|%|%',
      COALESCE(v_holder.full_name, ''),
      COALESCE(v_holder.email, ''),
      NEW."countryId"::text;
  END IF;

  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION get_bordereau_livraison ====
CREATE OR REPLACE FUNCTION public.get_bordereau_livraison(p_bordereau_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_bl bordereaux_livraison%ROWTYPE;
  v_colis jsonb;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  PERFORM public._assert_bordereau_access(v_bl.company_id);

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'id', ca.id,
    'statutColis', ca.statut_colis,
    'numeroRecu', ca.numero_recu,
    'nomExpediteur', ca.nom_expediteur,
    'telephoneExpediteur', ca.telephone_expediteur,
    'nomDestinataire', ca.nom_destinataire,
    'telephoneDestinataire', ca.telephone_destinataire,
    'descriptionContenu', ca.description_contenu,
    'poidsKg', ca.poids_kg,
    'nombrePieces', ca.nombre_pieces,
    'montantFret', ca.montant_fret,
    'gareDepart', gd.name,
    'gareDestination', gdest.name,
    'natures', (
      SELECT COALESCE(jsonb_agg(cn.libelle), '[]'::jsonb)
      FROM colis_natures_selectionnees cns
      JOIN colis_natures cn ON cn.id = cns.nature_id
      WHERE cns.colis_id = ca.id
    ),
    'addedAt', bc.added_at
  ) ORDER BY bc.added_at), '[]'::jsonb)
  INTO v_colis
  FROM bordereau_colis bc
  JOIN colis_autonomes ca ON ca.id = bc.colis_id
  JOIN "Gares" gd ON gd.id = ca.gare_depart_id
  JOIN "Gares" gdest ON gdest.id = ca.gare_destination_id
  WHERE bc.bordereau_id = p_bordereau_id;

  RETURN jsonb_build_object(
    'id', v_bl.id,
    'reference', v_bl.reference,
    'numeroLot', v_bl.numero_lot,
    'statut', v_bl.statut,
    'companyId', v_bl.company_id,
    'companyName', (SELECT name FROM "Companies" WHERE id = v_bl.company_id),
    'villeDepart', (SELECT name FROM "Cities" WHERE id = v_bl.ville_depart_id),
    'gareDestination', (SELECT name FROM "Gares" WHERE id = v_bl.gare_destination_id),
    'busPlateNumber', (SELECT "registrationNumber" FROM "Bus" WHERE id = v_bl.bus_id),
    'dateLot', v_bl.date_lot,
    'createdAt', v_bl.created_at,
    'closedAt', v_bl.closed_at,
    'colis', v_colis
  );
END;
$function$
;

-- ==== FUNCTION get_colis_autonome_detail ====
CREATE OR REPLACE FUNCTION public.get_colis_autonome_detail(p_colis_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_user_id uuid := public.current_app_user_id(); v_colis public.colis_autonomes%ROWTYPE; v_row jsonb;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  SELECT * INTO v_colis FROM public.colis_autonomes WHERE id = p_colis_id;
  IF v_colis.id IS NULL THEN RETURN NULL; END IF;
  IF NOT (
    public.is_company_role_user(v_user_id, v_colis.company_id)
    OR public.has_gare_colis_access(v_user_id, v_colis.company_id, v_colis.gare_depart_id, v_colis.gare_destination_id)
  ) THEN RAISE EXCEPTION 'Droits insuffisants'; END IF;
  SELECT jsonb_build_object('id', ca.id, 'companyId', ca.company_id, 'statutColis', ca.statut_colis, 'numeroRecu', ca.numero_recu, 'nomExpediteur', ca.nom_expediteur, 'telephoneExpediteur', ca.telephone_expediteur, 'nomDestinataire', ca.nom_destinataire, 'telephoneDestinataire', ca.telephone_destinataire, 'descriptionContenu', ca.description_contenu, 'poidsKg', ca.poids_kg, 'nombrePieces', ca.nombre_pieces, 'montantFret', ca.montant_fret, 'valeurMarchandise', ca.valeur_marchandise, 'sourceVente', ca.source_vente, 'createdAt', ca.created_at, 'updatedAt', ca.updated_at, 'gareDepartId', ca.gare_depart_id, 'gareDestinationId', ca.gare_destination_id, 'gareDepart', gd.name, 'gareDepartPhone', gd.phone, 'gareDestination', gdest.name, 'gareDestinationPhone', gdest.phone, 'companyName', c.name, 'companyPhone', c.phone, 'photoPath', ca.photo_path,
    'customFields', COALESCE(ca.custom_fields, '{}'::jsonb),
    'natureIds', COALESCE((SELECT jsonb_agg(cns.nature_id) FROM public.colis_natures_selectionnees cns WHERE cns.colis_id = ca.id), '[]'::jsonb),
    'natures', COALESCE((SELECT jsonb_agg(n.libelle ORDER BY n.libelle) FROM public.colis_natures_selectionnees cns JOIN public.colis_natures n ON n.id = cns.nature_id WHERE cns.colis_id = ca.id), '[]'::jsonb))
  INTO v_row FROM public.colis_autonomes ca JOIN "Gares" gd ON gd.id = ca.gare_depart_id JOIN "Gares" gdest ON gdest.id = ca.gare_destination_id JOIN "Companies" c ON c.id = ca.company_id WHERE ca.id = p_colis_id;
  RETURN v_row;
END; $function$
;

-- ==== FUNCTION get_colis_autonome_stats ====
CREATE OR REPLACE FUNCTION public.get_colis_autonome_stats(p_company_id uuid, p_vendeur_id uuid DEFAULT NULL::uuid, p_gare_depart_id uuid DEFAULT NULL::uuid, p_date_from timestamp with time zone DEFAULT NULL::timestamp with time zone, p_date_to timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_result jsonb;
  v_full_access boolean;
  v_gerant_gares uuid[];
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.is_company_role_user(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  v_full_access := public._colis_stats_full_access(v_user_id, p_company_id);
  IF NOT v_full_access THEN
    v_gerant_gares := public._colis_stats_gerant_gares(v_user_id, p_company_id);
    IF v_gerant_gares IS NULL THEN
      -- Rôle simple : uniquement SA propre activité.
      p_vendeur_id := v_user_id;
    END IF;
    -- Gérant : périmètre = ses gares (v_gerant_gares appliqué ci-dessous),
    -- filtre par agent autorisé DANS ce périmètre.
  END IF;

  WITH filtered AS (
    SELECT ca.*
    FROM public.colis_autonomes ca
    WHERE ca.company_id = p_company_id
      AND (v_gerant_gares IS NULL OR ca.gare_depart_id = ANY(v_gerant_gares))
      AND (p_vendeur_id IS NULL OR ca.vendeur_id = p_vendeur_id)
      AND (p_gare_depart_id IS NULL OR ca.gare_depart_id = p_gare_depart_id)
      AND (p_date_from IS NULL OR ca.created_at >= p_date_from)
      AND (p_date_to IS NULL OR ca.created_at < p_date_to)
  ),
  mine AS (
    SELECT ca.*
    FROM public.colis_autonomes ca
    WHERE ca.company_id = p_company_id
      AND ca.vendeur_id = v_user_id
      AND (p_gare_depart_id IS NULL OR ca.gare_depart_id = p_gare_depart_id)
      AND (p_date_from IS NULL OR ca.created_at >= p_date_from)
      AND (p_date_to IS NULL OR ca.created_at < p_date_to)
  )
  SELECT jsonb_build_object(
    'total', (SELECT COUNT(*) FROM filtered),
    'montantTotal', (SELECT COALESCE(SUM(montant_fret), 0) FROM filtered),
    'today', (SELECT COUNT(*) FROM filtered WHERE created_at::date = now()::date),
    'montantToday', (SELECT COALESCE(SUM(montant_fret), 0) FROM filtered WHERE created_at::date = now()::date),
    'thisMonth', (SELECT COUNT(*) FROM filtered WHERE date_trunc('month', created_at) = date_trunc('month', now())),
    'montantThisMonth', (SELECT COALESCE(SUM(montant_fret), 0) FROM filtered WHERE date_trunc('month', created_at) = date_trunc('month', now())),
    'delivered', (SELECT COUNT(*) FROM filtered WHERE statut_colis = 'livre'),
    'pending', (SELECT COUNT(*) FROM filtered WHERE statut_colis <> 'livre'),
    'mineTotal', (SELECT COUNT(*) FROM mine),
    'mineMontantTotal', (SELECT COALESCE(SUM(montant_fret), 0) FROM mine),
    'fullAccess', v_full_access,
    'gareScope', v_gerant_gares IS NOT NULL
  ) INTO v_result;

  RETURN v_result;
END;
$function$
;

-- ==== FUNCTION get_colis_prix_min ====
CREATE OR REPLACE FUNCTION public.get_colis_prix_min(p_company_id uuid, p_nature_ids uuid[], p_poids_kg double precision)
 RETURNS double precision
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT (public.is_company_role_user(v_user_id, p_company_id) OR public.is_super_admin()) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;
  RETURN public.compute_colis_prix_min(p_company_id, p_nature_ids, p_poids_kg);
END;
$function$
;

-- ==== FUNCTION get_colis_sales_journal ====
CREATE OR REPLACE FUNCTION public.get_colis_sales_journal(p_company_id uuid, p_date_from timestamp with time zone, p_date_to timestamp with time zone DEFAULT NULL::timestamp with time zone, p_vendeur_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_full_access boolean;
  v_gerant_gares uuid[];
  v_date_to timestamptz := COALESCE(p_date_to, p_date_from + interval '1 day');
  v_result jsonb;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.is_company_role_user(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  v_full_access := public._colis_stats_full_access(v_user_id, p_company_id);
  IF NOT v_full_access THEN
    v_gerant_gares := public._colis_stats_gerant_gares(v_user_id, p_company_id);
    IF v_gerant_gares IS NULL THEN
      p_vendeur_id := v_user_id;
    END IF;
  END IF;

  WITH filtered AS (
    SELECT
      ca.id,
      ca.numero_recu,
      ca.created_at,
      ca.nom_expediteur,
      ca.nom_destinataire,
      ca.montant_fret,
      ca.valeur_marchandise,
      ca.vendeur_id,
      gdest.name AS gare_destination
    FROM public.colis_autonomes ca
    JOIN "Gares" gdest ON gdest.id = ca.gare_destination_id
    WHERE ca.company_id = p_company_id
      AND ca.statut_colis <> 'annule'
      AND (v_gerant_gares IS NULL OR ca.gare_depart_id = ANY(v_gerant_gares))
      AND (p_vendeur_id IS NULL OR ca.vendeur_id = p_vendeur_id)
      AND ca.created_at >= p_date_from
      AND ca.created_at < v_date_to
  ),
  by_vendeur AS (
    SELECT
      f.vendeur_id,
      COALESCE(NULLIF(TRIM(COALESCE(u."firstName", '') || ' ' || COALESCE(u."lastName", '')), ''), u.username, 'Agent inconnu') AS vendeur_name,
      u.username AS vendeur_username,
      jsonb_agg(
        jsonb_build_object(
          'id', f.id,
          'numeroRecu', f.numero_recu,
          'createdAt', f.created_at,
          'nomExpediteur', f.nom_expediteur,
          'nomDestinataire', f.nom_destinataire,
          'montantFret', f.montant_fret,
          'valeurMarchandise', f.valeur_marchandise,
          'gareDestination', f.gare_destination
        )
        ORDER BY f.created_at
      ) AS colis,
      COUNT(*) AS cnt,
      COALESCE(SUM(f.montant_fret), 0) AS total_frais,
      COALESCE(SUM(f.valeur_marchandise), 0) AS total_valeur
    FROM filtered f
    LEFT JOIN "Users" u ON u.id = f.vendeur_id
    GROUP BY f.vendeur_id, u."firstName", u."lastName", u.username
  )
  SELECT jsonb_build_object(
    'groups', COALESCE(
      (SELECT jsonb_agg(
        jsonb_build_object(
          'vendeurId', bv.vendeur_id,
          'vendeurName', bv.vendeur_name,
          'vendeurUsername', bv.vendeur_username,
          'colis', bv.colis,
          'count', bv.cnt,
          'totalFrais', bv.total_frais,
          'totalValeur', bv.total_valeur
        )
        ORDER BY bv.vendeur_name
      ) FROM by_vendeur bv),
      '[]'::jsonb
    ),
    'grandCount', (SELECT COALESCE(SUM(cnt), 0) FROM by_vendeur),
    'grandTotalFrais', (SELECT COALESCE(SUM(total_frais), 0) FROM by_vendeur),
    'grandTotalValeur', (SELECT COALESCE(SUM(total_valeur), 0) FROM by_vendeur),
    'fullAccess', v_full_access,
    'gareScope', v_gerant_gares IS NOT NULL
  ) INTO v_result;

  RETURN v_result;
END;
$function$
;

-- ==== FUNCTION get_colis_today_by_gare ====
CREATE OR REPLACE FUNCTION public.get_colis_today_by_gare(p_company_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_result jsonb;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public._colis_gare_breakdown_access(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  SELECT COALESCE(jsonb_agg(row_to_json(t)), '[]'::jsonb) INTO v_result
  FROM (
    SELECT
      g.id AS "gareId",
      g.name AS "gareName",
      COUNT(ca.id) AS count,
      COALESCE(SUM(ca.montant_fret), 0) AS montant
    FROM public."Gares" g
    LEFT JOIN public.colis_autonomes ca
      ON ca.gare_depart_id = g.id
      AND ca.company_id = p_company_id
      AND ca.created_at::date = now()::date
    WHERE g."companyId" = p_company_id
      AND g.name <> '__CASH_SESSION_HUB__'
      AND g.name NOT LIKE '\_\_%'
    GROUP BY g.id, g.name
    ORDER BY montant DESC, g.name
  ) t;

  RETURN v_result;
END;
$function$
;

-- ==== FUNCTION get_company_colis_settings ====
CREATE OR REPLACE FUNCTION public.get_company_colis_settings(p_company_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_row "Companies"%ROWTYPE;
  v_sms_config_allowed boolean := false;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT (public.is_company_role_user(v_user_id, p_company_id) OR public.is_super_admin()) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  SELECT * INTO v_row FROM "Companies" WHERE id = p_company_id;
  IF v_row.id IS NULL THEN RAISE EXCEPTION 'Compagnie introuvable'; END IF;

  SELECT COALESCE(public.company_colis_sms_owner_config_enabled(p_company_id), false)
  INTO v_sms_config_allowed;

  RETURN jsonb_build_object(
    'companyId', v_row.id,
    'colisAutonomeEnabled', COALESCE(v_row.colis_autonome_enabled, false),
    'colisSmsConfigEnabled', v_sms_config_allowed,
    'smsOnEnregistre', COALESCE(v_row.sms_on_enregistre, false),
    'smsOnCharge', COALESCE(v_row.sms_on_charge, false),
    'smsOnArrive', COALESCE(v_row.sms_on_arrive, false),
    'smsOnLivre', COALESCE(v_row.sms_on_livre, false),
    'uiConfig', COALESCE(v_row.colis_ui_config, '{}'::jsonb)
  );
END;
$function$
;

-- ==== FUNCTION get_contact_options ====
CREATE OR REPLACE FUNCTION public.get_contact_options()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_platform text;
  v_platform_email text;
  v_companies jsonb;
BEGIN
  SELECT
    NULLIF(BTRIM(cs."whatsappNumber"), ''),
    NULLIF(BTRIM(cs."notificationEmail"), '')
  INTO v_platform, v_platform_email
  FROM "ContactSettings" cs
  WHERE cs."scope" = 'platform'
  LIMIT 1;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'companyId', cs."scope",
        'companyName', COALESCE(c.name, 'Compagnie'),
        'whatsappNumber', NULLIF(BTRIM(cs."whatsappNumber"), ''),
        'notificationEmail', NULLIF(BTRIM(cs."notificationEmail"), '')
      )
      ORDER BY c.name
    ),
    '[]'::jsonb
  )
  INTO v_companies
  FROM "ContactSettings" cs
  LEFT JOIN "Companies" c ON c.id::text = cs."scope"
  WHERE cs."scope" <> 'platform'
    AND (
      NULLIF(BTRIM(cs."whatsappNumber"), '') IS NOT NULL
      OR NULLIF(BTRIM(cs."notificationEmail"), '') IS NOT NULL
    );

  RETURN jsonb_build_object(
    'platformWhatsapp', v_platform,
    'platformNotificationEmail', v_platform_email,
    'companies', v_companies
  );
END;
$function$
;

-- ==== FUNCTION get_country_admin_pays_holder ====
CREATE OR REPLACE FUNCTION public.get_country_admin_pays_holder(p_country_id uuid, p_exclude_user_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(user_id uuid, full_name text, email text)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT
    u.id,
    NULLIF(TRIM(COALESCE(u."firstName", '') || ' ' || COALESCE(u."lastName", '')), '')::text,
    u.email::text
  FROM public."UserRoles" ur
  JOIN public."Role" r ON r.id = ur."roleId" AND r.name = 'admin_pays'
  JOIN public."Users" u ON u.id = ur."userId"
  WHERE ur."countryId" = p_country_id
    AND (p_exclude_user_id IS NULL OR ur."userId" <> p_exclude_user_id)
  ORDER BY u.email
  LIMIT 1;
$function$
;

-- ==== FUNCTION get_open_station_cash_for_user ====
CREATE OR REPLACE FUNCTION public.get_open_station_cash_for_user(p_gare_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
  v_row record;
  v_pending boolean;
  v_label text;
BEGIN
  v_user_id := public.current_app_user_id();
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Utilisateur introuvable'; END IF;
  SELECT c.*, g.name AS gare_name, g."companyId" AS company_id INTO v_row
  FROM caisses_gares c
  JOIN "Gares" g ON g.id = c.gare_id
  WHERE c.gestionnaire_id = v_user_id
    AND c.statut IN ('ouverte', 'en_reversement')
    AND (p_gare_id IS NULL OR c.gare_id = p_gare_id)
  ORDER BY c.opened_at DESC
  LIMIT 1;
  IF v_row.id IS NULL THEN RETURN jsonb_build_object('open', false); END IF;
  SELECT EXISTS (
    SELECT 1 FROM reversements_comptables r
    WHERE r.caisse_id = v_row.id AND r.statut_validation = 'en_attente'
  ) INTO v_pending;
  v_label := CASE
    WHEN v_row.gare_name = '__CASH_SESSION_HUB__' THEN 'Session caisse journaliere'
    ELSE v_row.gare_name
  END;
  RETURN jsonb_build_object(
    'open', v_row.statut = 'ouverte',
    'pendingReversal', v_pending OR v_row.statut = 'en_reversement',
    'id', v_row.id,
    'gareId', v_row.gare_id,
    'gareName', v_label,
    'sessionLabel', v_label,
    'balance', v_row.solde_especes_actuel,
    'openingFloat', v_row.fond_roulement,
    'openedAt', v_row.opened_at,
    'status', v_row.statut,
    'companyId', v_row.company_id
  );
END;
$function$
;

-- ==== FUNCTION has_company_droit ====
CREATE OR REPLACE FUNCTION public.has_company_droit(p_company_id uuid, p_droit text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT public.is_super_admin()
    OR EXISTS (
      SELECT 1 FROM "UserRoles" ur
      JOIN "Role" r ON r.id = ur."roleId"
      JOIN "Users" u ON u.id = ur."userId"
      WHERE u."auth_user_id" = auth.uid()
        AND ur."companyId" = p_company_id
        AND p_droit = ANY (r.droits)
    )
    OR EXISTS (
      SELECT 1 FROM "UserRoles" ur
      JOIN "Role" r ON r.id = ur."roleId"
      JOIN "Users" u ON u.id = ur."userId"
      JOIN "Companies" c ON c."countryId" = ur."countryId"
      WHERE u."auth_user_id" = auth.uid()
        AND c.id = p_company_id
        AND r.name = 'admin_pays'
        AND p_droit = ANY (r.droits)
    );
$function$
;

-- ==== FUNCTION has_company_role ====
CREATE OR REPLACE FUNCTION public.has_company_role(p_company_id uuid, p_roles text[])
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM "UserRoles" ur
    JOIN "Role" r ON r.id = ur."roleId"
    JOIN "Users" u ON u.id = ur."userId"
    WHERE u."auth_user_id" = auth.uid()
      AND ur."companyId" = p_company_id
      AND r.name = ANY (p_roles)
  );
$function$
;

-- ==== FUNCTION has_gare_colis_access ====
CREATE OR REPLACE FUNCTION public.has_gare_colis_access(p_user_id uuid, p_company_id uuid, p_gare_depart_id uuid, p_gare_destination_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1
    FROM "UserRoles" ur
    JOIN "Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = p_user_id
      AND ur."companyId" = p_company_id
      AND ur."gareId" IS NOT NULL
      AND r.name = 'comptable_gare'
      AND ur."gareId" IN (p_gare_depart_id, p_gare_destination_id)
  );
$function$
;

-- ==== FUNCTION has_gare_role ====
CREATE OR REPLACE FUNCTION public.has_gare_role(p_gare_id uuid, p_roles text[])
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public."UserRoles" ur
    JOIN public."Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = public.current_app_user_id()
      AND ur."gareId" = p_gare_id
      AND r.name = ANY (p_roles)
  ) OR public.is_super_admin();
$function$
;

-- ==== FUNCTION is_company_role_user ====
CREATE OR REPLACE FUNCTION public.is_company_role_user(p_user_id uuid, p_company_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1
    FROM "UserRoles" ur
    JOIN "Role" ro ON ro.id = ur."roleId"
    WHERE ur."userId" = p_user_id
      AND ur."companyId" = p_company_id
      AND ro.name IN ('owner', 'comptable_compagnie', 'controleur', 'vendeur',
                       'emballeur_gare', 'chargeur_gare', 'distributeur_gare')
  )
  OR public.has_company_droit(p_company_id, 'manage_feature_modules');
$function$
;

-- ==== FUNCTION is_super_admin ====
CREATE OR REPLACE FUNCTION public.is_super_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1
    FROM "UserRoles" ur
    JOIN "Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = public.current_app_user_id()
      AND r.name = 'super_admin'
  );
$function$
;

-- ==== FUNCTION list_bordereau_notify_contacts ====
CREATE OR REPLACE FUNCTION public.list_bordereau_notify_contacts(p_company_id uuid)
 RETURNS TABLE(user_id uuid, "firstName" text, "lastName" text, email text, phone text, role_name text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  PERFORM public._assert_bordereau_access(p_company_id);

  RETURN QUERY
  SELECT DISTINCT ON (u.id)
    u.id, u."firstName"::text, u."lastName"::text, u.email::text, u.phone::text, r.name::text
  FROM public."UserRoles" ur
  JOIN public."Role" r ON r.id = ur."roleId"
  JOIN public."Users" u ON u.id = ur."userId"
  WHERE ur."companyId" = p_company_id
    AND r.name IN ('owner', 'controleur')
  ORDER BY u.id, (r.name = 'owner') DESC;
END;
$function$
;

-- ==== FUNCTION list_bordereaux_livraison ====
CREATE OR REPLACE FUNCTION public.list_bordereaux_livraison(p_company_id uuid, p_limit integer DEFAULT 50)
 RETURNS TABLE(id uuid, reference text, "numeroLot" integer, statut text, "villeDepart" text, "gareDestination" text, "busPlateNumber" text, "colisCount" bigint, "dateLot" date, "createdAt" timestamp with time zone, "closedAt" timestamp with time zone)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  PERFORM public._assert_bordereau_access(p_company_id);
  RETURN QUERY
  SELECT bl.id, bl.reference, bl.numero_lot, bl.statut,
         vd.name::text, gdest.name::text, b."registrationNumber"::text,
         (SELECT count(*) FROM bordereau_colis bc WHERE bc.bordereau_id = bl.id),
         bl.date_lot, bl.created_at, bl.closed_at
  FROM bordereaux_livraison bl
  LEFT JOIN "Cities" vd ON vd.id = bl.ville_depart_id
  LEFT JOIN "Gares" gdest ON gdest.id = bl.gare_destination_id
  LEFT JOIN "Bus" b ON b.id = bl.bus_id
  WHERE bl.company_id = p_company_id
  ORDER BY bl.date_lot DESC, bl.created_at DESC
  LIMIT GREATEST(COALESCE(p_limit, 50), 1);
END;
$function$
;

-- ==== FUNCTION list_colis_autonomes ====
CREATE OR REPLACE FUNCTION public.list_colis_autonomes(p_company_id uuid, p_statut text DEFAULT NULL::text, p_limit integer DEFAULT 50, p_search text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_rows jsonb;
  v_full_access boolean;
  v_gare_ids uuid[];
  v_own_sales_role boolean;
  v_search text := NULLIF(trim(p_search), '');
  v_search_digits text;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;

  v_full_access := public._colis_stats_full_access(v_user_id, p_company_id)
    OR public.has_company_role(p_company_id, ARRAY['emballeur_gare','chargeur_gare','distributeur_gare']);

  IF NOT v_full_access THEN
    SELECT array_agg(ur."gareId") INTO v_gare_ids
    FROM "UserRoles" ur
    JOIN "Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = v_user_id
      AND ur."companyId" = p_company_id
      AND ur."gareId" IS NOT NULL
      AND r.name IN ('comptable_gare', 'emballeur_gare', 'chargeur_gare', 'distributeur_gare');
  END IF;

  IF NOT v_full_access AND v_gare_ids IS NULL THEN
    SELECT EXISTS (
      SELECT 1
      FROM "UserRoles" ur
      JOIN "Role" r ON r.id = ur."roleId"
      WHERE ur."userId" = v_user_id
        AND ur."companyId" = p_company_id
        AND r.name IN ('vendeur', 'vendeur_gare', 'chauffeur', 'controleur')
    ) INTO v_own_sales_role;
    IF NOT v_own_sales_role THEN
      RAISE EXCEPTION 'Droits insuffisants';
    END IF;
  END IF;

  v_search_digits := NULLIF(regexp_replace(COALESCE(v_search, ''), '[^0-9]', '', 'g'), '');

  SELECT COALESCE(jsonb_agg(row_to_json(sub)::jsonb ORDER BY sub."createdAt" DESC), '[]'::jsonb)
  INTO v_rows
  FROM (
    SELECT
      ca.id,
      ca.statut_colis AS "statutColis",
      ca.numero_recu AS "numeroRecu",
      ca.nom_expediteur AS "nomExpediteur",
      ca.telephone_expediteur AS "telephoneExpediteur",
      ca.nom_destinataire AS "nomDestinataire",
      ca.telephone_destinataire AS "telephoneDestinataire",
      ca.description_contenu AS "descriptionContenu",
      ca.poids_kg AS "poidsKg",
      ca.nombre_pieces AS "nombrePieces",
      ca.montant_fret AS "montantFret",
      ca.valeur_marchandise AS "valeurMarchandise",
      ca.created_at AS "createdAt",
      ca.updated_at AS "updatedAt",
      gd.name AS "gareDepart",
      gdest.name AS "gareDestination",
      COALESCE(ca.custom_fields, '{}'::jsonb) AS "customFields",
      COALESCE(
        (SELECT jsonb_agg(n.libelle ORDER BY n.libelle)
         FROM public.colis_natures_selectionnees cns
         JOIN public.colis_natures n ON n.id = cns.nature_id
         WHERE cns.colis_id = ca.id),
        '[]'::jsonb
      ) AS "natures"
    FROM public.colis_autonomes ca
    JOIN "Gares" gd ON gd.id = ca.gare_depart_id
    JOIN "Gares" gdest ON gdest.id = ca.gare_destination_id
    WHERE ca.company_id = p_company_id
      AND (p_statut IS NULL OR ca.statut_colis = p_statut)
      AND (
        v_full_access
        OR (v_gare_ids IS NOT NULL AND (ca.gare_depart_id = ANY(v_gare_ids) OR ca.gare_destination_id = ANY(v_gare_ids)))
        OR (v_gare_ids IS NULL AND ca.vendeur_id = v_user_id)
      )
      -- Recherche serveur : porte sur TOUTE la table (pas seulement les
      -- p_limit lignes les plus récentes) — corrige le cas où un colis
      -- plus ancien (ex. numero_recu "COCO000187") était invisible car
      -- hors de la fenêtre des N derniers colis chargés côté frontend.
      AND (
        v_search IS NULL
        OR ca.numero_recu ILIKE '%' || v_search || '%'
        OR ca.nom_expediteur ILIKE '%' || v_search || '%'
        OR ca.nom_destinataire ILIKE '%' || v_search || '%'
        OR public.colis_public_reference_sql(ca.id) ILIKE '%' || regexp_replace(v_search, '^[Cc][Ll]-?', '') || '%'
        OR (v_search_digits IS NOT NULL AND (
          regexp_replace(ca.telephone_expediteur, '\D', '', 'g') ILIKE '%' || v_search_digits || '%'
          OR regexp_replace(ca.telephone_destinataire, '\D', '', 'g') ILIKE '%' || v_search_digits || '%'
        ))
      )
    ORDER BY ca.created_at DESC
    LIMIT GREATEST(LEAST(COALESCE(p_limit, 50), 5000), 1)
  ) sub;

  RETURN v_rows;
END;
$function$
;

-- ==== FUNCTION list_colis_disponibles_bordereau ====
CREATE OR REPLACE FUNCTION public.list_colis_disponibles_bordereau(p_bordereau_id uuid, p_limit integer DEFAULT 200)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_bl bordereaux_livraison%ROWTYPE;
  v_rows jsonb;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  PERFORM public._assert_bordereau_access(v_bl.company_id);

  SELECT COALESCE(jsonb_agg(row_to_json(sub)::jsonb ORDER BY sub."createdAt" DESC), '[]'::jsonb)
  INTO v_rows
  FROM (
    SELECT
      ca.id,
      ca.statut_colis AS "statutColis",
      ca.numero_recu AS "numeroRecu",
      ca.nom_expediteur AS "nomExpediteur",
      ca.telephone_expediteur AS "telephoneExpediteur",
      ca.nom_destinataire AS "nomDestinataire",
      ca.telephone_destinataire AS "telephoneDestinataire",
      ca.description_contenu AS "descriptionContenu",
      ca.poids_kg AS "poidsKg",
      ca.nombre_pieces AS "nombrePieces",
      ca.montant_fret AS "montantFret",
      ca.valeur_marchandise AS "valeurMarchandise",
      ca.pourcentage_percu AS "pourcentagePercu",
      ca.bus_id AS "busId",
      b."registrationNumber" AS "busPlateNumber",
      ca.created_at AS "createdAt",
      ca.updated_at AS "updatedAt",
      gd.name AS "gareDepart",
      gdest.name AS "gareDestination",
      COALESCE(
        (SELECT jsonb_agg(n.libelle ORDER BY n.libelle)
         FROM public.colis_natures_selectionnees cns
         JOIN public.colis_natures n ON n.id = cns.nature_id
         WHERE cns.colis_id = ca.id),
        '[]'::jsonb
      ) AS "natures"
    FROM public.colis_autonomes ca
    JOIN "Gares" gd ON gd.id = ca.gare_depart_id
    JOIN "Gares" gdest ON gdest.id = ca.gare_destination_id
    LEFT JOIN "Bus" b ON b.id = ca.bus_id
    WHERE ca.company_id = v_bl.company_id
      AND gd."cityId" = v_bl.ville_depart_id
      AND (v_bl.gare_destination_id IS NULL OR ca.gare_destination_id = v_bl.gare_destination_id)
      AND ca.statut_colis <> 'livre'
      AND NOT EXISTS (
        SELECT 1
        FROM bordereau_colis bc
        JOIN bordereaux_livraison bl2 ON bl2.id = bc.bordereau_id
        WHERE bc.colis_id = ca.id AND bl2.statut = 'ouvert'
      )
    ORDER BY ca.created_at DESC
    LIMIT GREATEST(LEAST(COALESCE(p_limit, 200), 500), 1)
  ) sub;

  RETURN v_rows;
END;
$function$
;

-- ==== FUNCTION list_company_colis_vendeurs ====
CREATE OR REPLACE FUNCTION public.list_company_colis_vendeurs(p_company_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_rows jsonb;
  v_gerant_gares uuid[];
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.is_company_role_user(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  IF NOT public._colis_stats_full_access(v_user_id, p_company_id) THEN
    v_gerant_gares := public._colis_stats_gerant_gares(v_user_id, p_company_id);
    IF v_gerant_gares IS NULL THEN
      RETURN '[]'::jsonb;
    END IF;
  END IF;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'id', u.id,
        'name', COALESCE(NULLIF(TRIM(u."firstName" || ' ' || u."lastName"), ''), u.username)
      )
      ORDER BY COALESCE(NULLIF(TRIM(u."firstName" || ' ' || u."lastName"), ''), u.username)
    ),
    '[]'::jsonb
  )
  INTO v_rows
  FROM (
    SELECT DISTINCT ca.vendeur_id
    FROM public.colis_autonomes ca
    WHERE ca.company_id = p_company_id
      AND ca.vendeur_id IS NOT NULL
      AND (v_gerant_gares IS NULL OR ca.gare_depart_id = ANY(v_gerant_gares))
  ) v
  JOIN "Users" u ON u.id = v.vendeur_id;

  RETURN v_rows;
END;
$function$
;

-- ==== FUNCTION list_company_gares_for_stats ====
CREATE OR REPLACE FUNCTION public.list_company_gares_for_stats(p_company_id uuid)
 RETURNS TABLE(id uuid, name text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.is_company_role_user(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  RETURN QUERY
  SELECT g.id, g.name::text
  FROM public."Gares" g
  WHERE g."companyId" = p_company_id
    AND g.name <> '__CASH_SESSION_HUB__'
    AND g.name NOT LIKE '\_\_%'
  ORDER BY g.name;
END;
$function$
;

-- ==== FUNCTION list_company_villes_depart ====
CREATE OR REPLACE FUNCTION public.list_company_villes_depart(p_company_id uuid)
 RETURNS TABLE(id uuid, name text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.is_company_role_user(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;

  RETURN QUERY
  SELECT DISTINCT c.id, c.name::text AS name
  FROM public."Cities" c
  JOIN public."Gares" g ON g."cityId" = c.id
  WHERE g."companyId" = p_company_id
    AND g.name <> '__CASH_SESSION_HUB__'
    AND g.name NOT LIKE '\_\_%'
  ORDER BY name;
END;
$function$
;

-- ==== FUNCTION list_my_notifications ====
CREATE OR REPLACE FUNCTION public.list_my_notifications(p_limit integer DEFAULT 20)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT COALESCE(jsonb_agg(row_data ORDER BY created_at DESC), '[]'::jsonb)
  FROM (
    SELECT jsonb_build_object(
      'id', n.id,
      'type', n.type,
      'title', n.title,
      'message', n.message,
      'isRead', n."isRead",
      'metadata', n.metadata,
      'createdAt', n."createdAt"
    ) AS row_data,
    n."createdAt" AS created_at
    FROM "Notifications" n
    WHERE n."userId" = public.current_app_user_id()
    ORDER BY n."createdAt" DESC
    LIMIT LEAST(GREATEST(COALESCE(p_limit, 20), 1), 100)
  ) t;
$function$
;

-- ==== FUNCTION list_station_cash_movements ====
CREATE OR REPLACE FUNCTION public.list_station_cash_movements(p_caisse_id uuid, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0)
 RETURNS TABLE(id uuid, created_at timestamp with time zone, type_mouvement text, montant integer, solde_apres integer, ticket_id uuid, colis_id uuid, effectue_par_name text, note text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_company_id uuid;
BEGIN
  SELECT public.station_cash_gare_company_id(c.gare_id) INTO v_company_id
  FROM caisses_gares c
  WHERE c.id = p_caisse_id;
  IF v_company_id IS NULL THEN RAISE EXCEPTION 'Caisse introuvable'; END IF;
  IF NOT (
    public.is_super_admin()
    OR public.can_operate_station_cash(v_company_id)
    OR public.can_validate_station_reversal(v_company_id)
  ) THEN
    RAISE EXCEPTION 'Acces mouvements refuse';
  END IF;

  RETURN QUERY
  SELECT
    m.id,
    m.created_at,
    m.type_mouvement,
    m.montant,
    m.solde_apres,
    m.ticket_id,
    COALESCE(m.colis_autonome_id, m.colis_id) AS colis_id,
    NULLIF(TRIM(u."firstName" || ' ' || u."lastName"), ''),
    m.note
  FROM mouvements_caisse m
  LEFT JOIN "Users" u ON u.id = m.effectue_par
  WHERE m.caisse_id = p_caisse_id
  ORDER BY m.created_at DESC
  LIMIT GREATEST(1, LEAST(COALESCE(p_limit, 100), 500))
  OFFSET GREATEST(COALESCE(p_offset, 0), 0);
END;
$function$
;

-- ==== FUNCTION mark_all_my_notifications_read ====
CREATE OR REPLACE FUNCTION public.mark_all_my_notifications_read()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE "Notifications" SET "isRead" = true
  WHERE "userId" = public.current_app_user_id() AND "isRead" = false;
END;
$function$
;

-- ==== FUNCTION mark_bordereau_arrive ====
CREATE OR REPLACE FUNCTION public.mark_bordereau_arrive(p_bordereau_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_bl bordereaux_livraison%ROWTYPE;
  v_company_name text;
  v_ville_depart_name text;
  v_gare_destination_name text;
  v_row record;
  v_results jsonb := '[]'::jsonb;
  v_notify_recipients uuid[];
  v_notify_title text;
  v_notify_message text;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  IF v_bl.gare_destination_id IS NULL THEN RAISE EXCEPTION 'Lot sans gare de destination'; END IF;
  PERFORM public._assert_lot_access(v_bl.company_id, v_bl.gare_destination_id, ARRAY['distributeur_gare']);
  IF v_bl.statut <> 'charge' THEN
    RAISE EXCEPTION 'Le lot doit d''abord etre charge (parti) avant confirmation de reception';
  END IF;

  SELECT c.name INTO v_company_name FROM "Companies" c WHERE c.id = v_bl.company_id;
  SELECT name INTO v_ville_depart_name FROM "Cities" WHERE id = v_bl.ville_depart_id;
  SELECT name INTO v_gare_destination_name FROM "Gares" WHERE id = v_bl.gare_destination_id;

  FOR v_row IN
    SELECT ca.* FROM colis_autonomes ca
    JOIN bordereau_colis bc ON bc.colis_id = ca.id
    WHERE bc.bordereau_id = p_bordereau_id AND ca.statut_colis = 'charge'
  LOOP
    UPDATE colis_autonomes SET statut_colis = 'arrive', updated_at = now() WHERE id = v_row.id;

    v_results := v_results || jsonb_build_object(
      'colisId', v_row.id,
      'telephoneExpediteur', v_row.telephone_expediteur,
      'telephoneDestinataire', v_row.telephone_destinataire,
      'sms', public.build_colis_sms_payload(
        v_bl.company_id, 'arrive',
        public.build_colis_sms_message('arrive', v_row.id, v_company_name, v_ville_depart_name, v_gare_destination_name),
        v_row.telephone_expediteur, v_row.telephone_destinataire
      )
    );
  END LOOP;

  UPDATE bordereaux_livraison SET statut = 'arrive' WHERE id = p_bordereau_id;

  v_notify_recipients := public._colis_notification_recipients(
    v_bl.company_id, NULL, v_bl.gare_destination_id, v_user_id
  );
  v_notify_title := 'Lot arrivé';
  v_notify_message := format('Lot %s (%s → %s) arrivé — %s colis', COALESCE(v_bl.numero_lot::text, v_bl.reference), v_ville_depart_name, v_gare_destination_name, jsonb_array_length(v_results));
  PERFORM public._create_colis_notifications(
    v_notify_recipients, 'lot_arrive', v_notify_title, v_notify_message,
    jsonb_build_object('bordereauId', p_bordereau_id, 'companyId', v_bl.company_id)
  );

  RETURN jsonb_build_object(
    'id', p_bordereau_id, 'statut', 'arrive', 'colisNotifications', v_results,
    'notifyRecipients', to_jsonb(v_notify_recipients),
    'notifyTitle', v_notify_title,
    'notifyMessage', v_notify_message
  );
END;
$function$
;

-- ==== FUNCTION mark_bordereau_charge ====
CREATE OR REPLACE FUNCTION public.mark_bordereau_charge(p_bordereau_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_bl bordereaux_livraison%ROWTYPE;
  v_company_name text;
  v_ville_depart_name text;
  v_gare_destination_name text;
  v_row record;
  v_results jsonb := '[]'::jsonb;
  v_notify_recipients uuid[];
  v_notify_title text;
  v_notify_message text;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  PERFORM public._assert_lot_access_ville(v_bl.company_id, v_bl.ville_depart_id, ARRAY['emballeur_gare','chargeur_gare']);
  IF v_bl.statut <> 'clos' THEN
    RAISE EXCEPTION 'Le lot doit d''abord etre cloture (emballage termine) avant chargement';
  END IF;

  SELECT c.name INTO v_company_name FROM "Companies" c WHERE c.id = v_bl.company_id;
  SELECT name INTO v_ville_depart_name FROM "Cities" WHERE id = v_bl.ville_depart_id;
  SELECT name INTO v_gare_destination_name FROM "Gares" WHERE id = v_bl.gare_destination_id;

  FOR v_row IN
    SELECT ca.* FROM colis_autonomes ca
    JOIN bordereau_colis bc ON bc.colis_id = ca.id
    WHERE bc.bordereau_id = p_bordereau_id AND ca.statut_colis = 'enregistre'
  LOOP
    UPDATE colis_autonomes
    SET statut_colis = 'charge', bus_id = COALESCE(v_bl.bus_id, bus_id), updated_at = now()
    WHERE id = v_row.id;

    v_results := v_results || jsonb_build_object(
      'colisId', v_row.id,
      'sms', public.build_colis_sms_payload(
        v_bl.company_id, 'charge',
        public.build_colis_sms_message('charge', v_row.id, v_company_name, v_ville_depart_name, v_gare_destination_name),
        v_row.telephone_expediteur, v_row.telephone_destinataire
      )
    );
  END LOOP;

  UPDATE bordereaux_livraison SET statut = 'charge' WHERE id = p_bordereau_id;

  v_notify_recipients := public._colis_notification_recipients(
    v_bl.company_id, NULL, v_bl.gare_destination_id, v_user_id
  );
  v_notify_title := 'Lot chargé';
  v_notify_message := format('Lot %s (%s → %s) chargé — %s colis', COALESCE(v_bl.numero_lot::text, v_bl.reference), v_ville_depart_name, v_gare_destination_name, jsonb_array_length(v_results));
  PERFORM public._create_colis_notifications(
    v_notify_recipients, 'lot_charge', v_notify_title, v_notify_message,
    jsonb_build_object('bordereauId', p_bordereau_id, 'companyId', v_bl.company_id)
  );

  RETURN jsonb_build_object(
    'id', p_bordereau_id, 'statut', 'charge', 'colisNotifications', v_results,
    'notifyRecipients', to_jsonb(v_notify_recipients),
    'notifyTitle', v_notify_title,
    'notifyMessage', v_notify_message
  );
END;
$function$
;

-- ==== FUNCTION mark_my_notification_read ====
CREATE OR REPLACE FUNCTION public.mark_my_notification_read(p_notification_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE "Notifications" SET "isRead" = true
  WHERE id = p_notification_id AND "userId" = public.current_app_user_id();
END;
$function$
;

-- ==== FUNCTION normalize_phone_digits ====
CREATE OR REPLACE FUNCTION public.normalize_phone_digits(p_phone text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT NULLIF(regexp_replace(COALESCE(p_phone, ''), '[^0-9]', '', 'g'), '');
$function$
;

-- ==== FUNCTION open_station_cash_register ====
CREATE OR REPLACE FUNCTION public.open_station_cash_register(p_gare_id uuid DEFAULT NULL::uuid, p_fond_roulement integer DEFAULT 0, p_company_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
  v_company_id uuid;
  v_gare_id uuid;
  v_gare_name text;
  v_id uuid;
  v_fond integer;
  v_all_gares boolean;
BEGIN
  v_user_id := public.current_app_user_id();
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Utilisateur introuvable'; END IF;
  v_fond := GREATEST(COALESCE(p_fond_roulement, 0), 0);

  IF p_company_id IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1
      FROM public."UserRoles" ur
      JOIN public."Role" r ON r.id = ur."roleId"
      WHERE ur."userId" = v_user_id
        AND ur."companyId" = p_company_id
        AND r.name IN ('owner', 'vendeur', 'vendeur_gare', 'chauffeur')
    ) AND NOT public.is_super_admin() THEN
      RAISE EXCEPTION 'Aucun role de vente dans cette compagnie';
    END IF;
    v_company_id := p_company_id;
  ELSE
    v_company_id := public.resolve_seller_company_id(v_user_id);
  END IF;

  IF v_company_id IS NULL THEN
    RAISE EXCEPTION 'Ouverture reservee aux vendeurs rattaches a une compagnie';
  END IF;
  IF NOT public.can_operate_station_cash(v_company_id) THEN
    RAISE EXCEPTION 'Ouverture caisse non autorisee pour ce compte';
  END IF;
  IF p_gare_id IS NULL THEN
    RAISE EXCEPTION 'Selectionnez une gare pour ouvrir la caisse';
  END IF;
  IF NOT EXISTS (
    SELECT 1
    FROM public."Gares" g
    WHERE g.id = p_gare_id
      AND g."companyId" = v_company_id
      AND g.name <> '__CASH_SESSION_HUB__'
      AND g.name NOT LIKE '\_\_%'
  ) THEN
    RAISE EXCEPTION 'Gare invalide pour cette compagnie';
  END IF;

  SELECT public.is_super_admin()
    OR EXISTS (
      SELECT 1
      FROM public."UserRoles" ur
      JOIN public."Role" r ON r.id = ur."roleId"
      WHERE ur."userId" = v_user_id
        AND ur."companyId" = v_company_id
        AND r.name IN ('owner', 'vendeur', 'chauffeur')
    )
  INTO v_all_gares;

  IF NOT v_all_gares AND NOT EXISTS (
    SELECT 1
    FROM public."UserRoles" ur
    JOIN public."Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = v_user_id
      AND ur."gareId" = p_gare_id
      AND ur."companyId" = v_company_id
      AND r.name = 'vendeur_gare'
  ) THEN
    RAISE EXCEPTION 'Ouverture reservee a votre gare assignee';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.caisses_gares c
    WHERE c.gestionnaire_id = v_user_id
      AND c.statut IN ('ouverte', 'en_reversement')
  ) THEN
    RAISE EXCEPTION 'Une session de caisse est deja active ou en attente de validation';
  END IF;

  v_gare_id := p_gare_id;
  SELECT g.name::text INTO v_gare_name FROM public."Gares" g WHERE g.id = v_gare_id;

  INSERT INTO public.caisses_gares (gare_id, gestionnaire_id, solde_especes_actuel, statut, fond_roulement, opened_at)
  VALUES (v_gare_id, v_user_id, v_fond, 'ouverte', v_fond, now())
  RETURNING id INTO v_id;

  RETURN jsonb_build_object(
    'id', v_id,
    'gareId', v_gare_id,
    'gareName', v_gare_name,
    'sessionLabel', v_gare_name,
    'balance', v_fond,
    'openingFloat', v_fond,
    'status', 'ouverte'
  );
END;
$function$
;

-- ==== FUNCTION process_loyalty_on_colis ====
CREATE OR REPLACE FUNCTION public.process_loyalty_on_colis(p_colis_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_colis public.colis_autonomes%ROWTYPE;
  v_loyalty_user_id uuid;
  v_settings "CompanyLoyaltySettings"%ROWTYPE;
  v_balance_row "TravelerLoyaltyBalance"%ROWTYPE;
  v_points_earned integer := 0;
  v_new_balance integer := 0;
  v_phone_digits text;
BEGIN
  SELECT * INTO v_colis FROM public.colis_autonomes WHERE id = p_colis_id;
  IF v_colis.id IS NULL THEN RETURN; END IF;

  v_phone_digits := public.normalize_phone_digits(v_colis.telephone_expediteur);
  IF v_phone_digits IS NULL THEN RETURN; END IF;

  -- Expéditeur identifié uniquement par nom/téléphone au guichet (pas de
  -- compte requis pour envoyer un colis) : on ne crédite que s'il existe
  -- déjà un compte Users avec ce même numéro (correspondance exacte).
  SELECT u.id INTO v_loyalty_user_id
  FROM "Users" u
  WHERE public.normalize_phone_digits(u.phone) = v_phone_digits
  LIMIT 1;

  IF v_loyalty_user_id IS NULL THEN RETURN; END IF;

  SELECT * INTO v_settings FROM "CompanyLoyaltySettings" WHERE "companyId" = v_colis.company_id;
  IF v_settings."companyId" IS NULL OR NOT v_settings."isActive" THEN RETURN; END IF;
  IF v_colis.montant_fret <= 0 OR v_settings."spendUnitAmount" <= 0 THEN RETURN; END IF;

  v_points_earned := FLOOR(v_colis.montant_fret / v_settings."spendUnitAmount")::integer * v_settings."pointsPerSpendUnit";
  IF v_points_earned <= 0 THEN RETURN; END IF;

  SELECT * INTO v_balance_row
  FROM "TravelerLoyaltyBalance"
  WHERE "userId" = v_loyalty_user_id AND "companyId" = v_colis.company_id
  FOR UPDATE;

  IF v_balance_row."id" IS NULL THEN
    INSERT INTO "TravelerLoyaltyBalance" ("userId", "companyId", "pointsBalance", "lifetimeEarned")
    VALUES (v_loyalty_user_id, v_colis.company_id, 0, 0)
    RETURNING * INTO v_balance_row;
  END IF;

  v_new_balance := v_balance_row."pointsBalance" + v_points_earned;
  UPDATE "TravelerLoyaltyBalance"
  SET
    "pointsBalance" = v_new_balance,
    "lifetimeEarned" = "lifetimeEarned" + v_points_earned,
    "updatedAt" = now()
  WHERE "id" = v_balance_row."id";

  INSERT INTO "LoyaltyPointLedger" (
    "userId", "companyId", "colisId", "entryType", "pointsDelta", "balanceAfter", "note"
  )
  VALUES (
    v_loyalty_user_id, v_colis.company_id, p_colis_id, 'earn', v_points_earned, v_new_balance,
    'Points gagnes sur colis'
  );
EXCEPTION WHEN OTHERS THEN
  -- Best-effort absolu : un souci de fidélité ne doit jamais faire échouer
  -- l'enregistrement d'un colis (voir appel dans register_colis_autonome).
  NULL;
END;
$function$
;

-- ==== FUNCTION record_station_cash_movement ====
CREATE OR REPLACE FUNCTION public.record_station_cash_movement(p_caisse_id uuid, p_type_mouvement text, p_montant integer, p_ticket_id uuid DEFAULT NULL::uuid, p_colis_id uuid DEFAULT NULL::uuid, p_effectue_par uuid DEFAULT NULL::uuid, p_reversement_id uuid DEFAULT NULL::uuid, p_note text DEFAULT NULL::text, p_direction text DEFAULT 'in'::text, p_colis_autonome_id uuid DEFAULT NULL::uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_caisse record;
  v_user_id uuid;
  v_delta integer;
  v_new_balance integer;
  v_movement_id uuid;
BEGIN
  IF COALESCE(p_montant, 0) <= 0 THEN RAISE EXCEPTION 'Montant mouvement invalide'; END IF;
  v_user_id := COALESCE(p_effectue_par, public.current_app_user_id());
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Utilisateur introuvable'; END IF;

  SELECT * INTO v_caisse FROM caisses_gares WHERE id = p_caisse_id FOR UPDATE;
  IF v_caisse.id IS NULL THEN RAISE EXCEPTION 'Caisse introuvable'; END IF;
  IF v_caisse.statut <> 'ouverte' AND p_type_mouvement <> 'reversement_comptable' THEN
    RAISE EXCEPTION 'Caisse cloturee';
  END IF;

  v_delta := CASE WHEN p_direction = 'out' THEN -p_montant ELSE p_montant END;
  v_new_balance := v_caisse.solde_especes_actuel + v_delta;
  IF v_new_balance < 0 THEN
    RAISE EXCEPTION 'Solde caisse insuffisant (solde: %, mouvement: %)', v_caisse.solde_especes_actuel, v_delta;
  END IF;

  UPDATE caisses_gares SET solde_especes_actuel = v_new_balance WHERE id = p_caisse_id;

  INSERT INTO mouvements_caisse (
    caisse_id, type_mouvement, montant, solde_apres,
    ticket_id, colis_id, colis_autonome_id, effectue_par, reversement_id, note
  ) VALUES (
    p_caisse_id, p_type_mouvement, p_montant, v_new_balance,
    p_ticket_id, p_colis_id, p_colis_autonome_id, v_user_id, p_reversement_id, NULLIF(trim(p_note), '')
  ) RETURNING id INTO v_movement_id;

  RETURN v_movement_id;
END;
$function$
;

-- ==== FUNCTION register_colis_autonome ====
CREATE OR REPLACE FUNCTION public.register_colis_autonome(p_company_id uuid, p_gare_depart_id uuid, p_gare_destination_id uuid, p_nom_expediteur text, p_telephone_expediteur text, p_nom_destinataire text, p_telephone_destinataire text, p_description_contenu text, p_poids_kg double precision, p_nombre_pieces integer, p_montant_fret double precision, p_nature_ids uuid[], p_valeur_marchandise double precision DEFAULT NULL::double precision, p_pourcentage_percu double precision DEFAULT NULL::double precision, p_bus_id uuid DEFAULT NULL::uuid, p_custom_fields jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_colis_id uuid;
  v_nature_id uuid;
  v_caisse_id uuid;
  v_montant_fcfa integer;
  v_company_name text;
  v_gare_depart text;
  v_gare_destination text;
  v_sms_message text;
  v_prix_min double precision;
  v_notify_recipients uuid[];
  v_notify_title text;
  v_notify_message text;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  IF NOT public.is_company_role_user(v_user_id, p_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;
  IF NOT public.company_colis_module_enabled(p_company_id) THEN
    RAISE EXCEPTION 'Module colis autonome non active';
  END IF;
  IF p_gare_depart_id = p_gare_destination_id THEN
    RAISE EXCEPTION 'Gare de depart et destination doivent etre differentes';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM "Gares" g WHERE g.id = p_gare_depart_id AND g."companyId" = p_company_id
  ) THEN
    RAISE EXCEPTION 'Gare de depart invalide';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM "Gares" g WHERE g.id = p_gare_destination_id AND g."companyId" = p_company_id
  ) THEN
    RAISE EXCEPTION 'Gare de destination invalide';
  END IF;
  IF COALESCE(array_length(p_nature_ids, 1), 0) = 0 THEN
    RAISE EXCEPTION 'Selectionnez au moins une nature de colis';
  END IF;
  IF COALESCE(p_valeur_marchandise, 0) <= 0 THEN
    RAISE EXCEPTION 'Valeur marchandise obligatoire (sert de base au remboursement en cas de perte)';
  END IF;
  IF p_bus_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM "Bus" b WHERE b.id = p_bus_id AND b."companyId" = p_company_id
  ) THEN
    RAISE EXCEPTION 'Bus invalide';
  END IF;

  v_prix_min := public.compute_colis_prix_min(p_company_id, p_nature_ids, p_poids_kg);
  IF v_prix_min > 0 AND COALESCE(p_montant_fret, 0) < v_prix_min THEN
    RAISE EXCEPTION 'Montant fret insuffisant : minimum requis % XOF', ROUND(v_prix_min);
  END IF;

  SELECT c.id INTO v_caisse_id
  FROM caisses_gares c
  WHERE c.gestionnaire_id = v_user_id
    AND c.statut = 'ouverte'
  ORDER BY c.opened_at DESC
  LIMIT 1;

  IF v_caisse_id IS NULL THEN
    RAISE EXCEPTION 'Ouvrez votre caisse avant une vente cash';
  END IF;

  PERFORM public.assert_seller_cash_departure_gare(v_caisse_id, p_gare_depart_id);

  INSERT INTO public.colis_autonomes (
    company_id, gare_depart_id, gare_destination_id,
    nom_expediteur, telephone_expediteur, nom_destinataire, telephone_destinataire,
    description_contenu, poids_kg, nombre_pieces, montant_fret, valeur_marchandise,
    pourcentage_percu, bus_id, custom_fields,
    vendeur_id, source_vente, statut_colis
  ) VALUES (
    p_company_id, p_gare_depart_id, p_gare_destination_id,
    btrim(p_nom_expediteur), btrim(p_telephone_expediteur),
    btrim(p_nom_destinataire), btrim(p_telephone_destinataire),
    NULLIF(btrim(COALESCE(p_description_contenu, '')), ''),
    NULLIF(p_poids_kg, 0),
    GREATEST(COALESCE(p_nombre_pieces, 1), 1),
    GREATEST(COALESCE(p_montant_fret, 0), 0),
    p_valeur_marchandise,
    CASE WHEN COALESCE(p_pourcentage_percu, 0) > 0 THEN p_pourcentage_percu ELSE NULL END,
    p_bus_id,
    COALESCE(p_custom_fields, '{}'::jsonb),
    v_user_id, 'guichet_cash', 'enregistre'
  ) RETURNING id INTO v_colis_id;

  FOREACH v_nature_id IN ARRAY p_nature_ids LOOP
    IF NOT EXISTS (
      SELECT 1 FROM public.colis_natures n
      WHERE n.id = v_nature_id AND n.company_id = p_company_id AND n.is_active
    ) THEN
      RAISE EXCEPTION 'Nature de colis invalide: %', v_nature_id;
    END IF;
    INSERT INTO public.colis_natures_selectionnees (colis_id, nature_id)
    VALUES (v_colis_id, v_nature_id);
  END LOOP;

  v_montant_fcfa := ROUND(GREATEST(COALESCE(p_montant_fret, 0), 0))::integer;
  IF v_montant_fcfa > 0 THEN
    PERFORM public.record_station_cash_movement(
      v_caisse_id,
      'encaissement_colis',
      v_montant_fcfa,
      NULL,
      NULL,
      v_user_id,
      NULL,
      'Vente colis guichet',
      'in',
      v_colis_id
    );
  END IF;

  PERFORM public.process_loyalty_on_colis(v_colis_id);

  SELECT c.name, gd.name, gdest.name
  INTO v_company_name, v_gare_depart, v_gare_destination
  FROM "Companies" c
  JOIN "Gares" gd ON gd.id = p_gare_depart_id
  JOIN "Gares" gdest ON gdest.id = p_gare_destination_id
  WHERE c.id = p_company_id;

  v_sms_message := public.build_colis_sms_message(
    'enregistre', v_colis_id, v_company_name, v_gare_depart, v_gare_destination
  );

  v_notify_recipients := public._colis_notification_recipients(
    p_company_id, p_gare_depart_id, p_gare_destination_id, v_user_id
  );
  v_notify_title := 'Nouveau colis enregistré';
  v_notify_message := format('%s → %s · %s XOF', v_gare_depart, v_gare_destination, v_montant_fcfa);
  PERFORM public._create_colis_notifications(
    v_notify_recipients, 'colis_vente', v_notify_title, v_notify_message,
    jsonb_build_object('colisId', v_colis_id, 'companyId', p_company_id)
  );

  RETURN jsonb_build_object(
    'id', v_colis_id,
    'statutColis', 'enregistre',
    'montantFret', GREATEST(COALESCE(p_montant_fret, 0), 0),
    'sms', public.build_colis_sms_payload(
      p_company_id,
      'enregistre',
      v_sms_message,
      p_telephone_expediteur,
      p_telephone_destinataire
    ),
    'notifyRecipients', to_jsonb(v_notify_recipients),
    'notifyTitle', v_notify_title,
    'notifyMessage', v_notify_message
  );
END;
$function$
;

-- ==== FUNCTION register_device_token ====
CREATE OR REPLACE FUNCTION public.register_device_token(p_fcm_token character varying, p_platform character varying, p_app_version character varying DEFAULT NULL::character varying)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT "id" INTO v_user_id FROM "Users" WHERE "auth_user_id" = auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Utilisateur introuvable';
  END IF;

  INSERT INTO "DeviceTokens" ("userId", "fcmToken", "platform", "appVersion", "lastSeenAt")
  VALUES (v_user_id, p_fcm_token, p_platform, p_app_version, now())
  ON CONFLICT ("fcmToken") DO UPDATE SET
    "userId" = EXCLUDED."userId",
    "lastSeenAt" = now(),
    "appVersion" = EXCLUDED."appVersion";
END;
$function$
;

-- ==== FUNCTION remove_colis_from_bordereau ====
CREATE OR REPLACE FUNCTION public.remove_colis_from_bordereau(p_bordereau_id uuid, p_colis_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_bl bordereaux_livraison%ROWTYPE;
BEGIN
  SELECT * INTO v_bl FROM bordereaux_livraison WHERE id = p_bordereau_id;
  IF v_bl.id IS NULL THEN RAISE EXCEPTION 'Bordereau introuvable'; END IF;
  PERFORM public._assert_lot_access_ville(v_bl.company_id, v_bl.ville_depart_id, ARRAY['emballeur_gare','chargeur_gare']);
  IF v_bl.statut <> 'ouvert' THEN RAISE EXCEPTION 'Lot cloture'; END IF;
  DELETE FROM bordereau_colis WHERE bordereau_id = p_bordereau_id AND colis_id = p_colis_id;
END;
$function$
;

-- ==== FUNCTION resolve_colis_retrait_code ====
CREATE OR REPLACE FUNCTION public.resolve_colis_retrait_code(p_code text)
 RETURNS uuid
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_raw text := upper(trim(p_code));
  v_alnum text;
  v_id uuid;
BEGIN
  IF v_raw IS NULL OR v_raw = '' THEN
    RETURN NULL;
  END IF;

  BEGIN
    v_id := v_raw::uuid;
    IF EXISTS (SELECT 1 FROM public.colis_autonomes WHERE id = v_id) THEN
      RETURN v_id;
    END IF;
  EXCEPTION
    WHEN invalid_text_representation THEN
      NULL;
  END;

  v_alnum := regexp_replace(v_raw, '[^A-Z0-9]', '', 'g');

  -- Numéro de reçu par gare (ex. ABOI000001).
  SELECT ca.id INTO v_id
  FROM public.colis_autonomes ca
  WHERE upper(ca.numero_recu) = v_alnum
  LIMIT 1;
  IF v_id IS NOT NULL THEN RETURN v_id; END IF;

  v_raw := regexp_replace(v_alnum, '^CL-?', '');
  IF length(v_raw) < 4 THEN
    RETURN NULL;
  END IF;

  SELECT ca.id
  INTO v_id
  FROM public.colis_autonomes ca
  WHERE upper(replace(ca.id::text, '-', '')) LIKE v_raw || '%'
  ORDER BY ca.created_at DESC
  LIMIT 1;

  IF v_id IS NULL AND length(v_raw) > 8 THEN
    SELECT ca.id
    INTO v_id
    FROM public.colis_autonomes ca
    WHERE upper(replace(ca.id::text, '-', '')) LIKE left(v_raw, 8) || '%'
    ORDER BY ca.created_at DESC
    LIMIT 1;
  END IF;

  RETURN v_id;
END;
$function$
;

-- ==== FUNCTION resolve_seller_company_id ====
CREATE OR REPLACE FUNCTION public.resolve_seller_company_id(p_user_id uuid DEFAULT NULL::uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user uuid := COALESCE(p_user_id, public.current_app_user_id());
BEGIN
  IF v_user IS NULL THEN RETURN NULL; END IF;

  RETURN (
    SELECT ur."companyId"
    FROM public."UserRoles" ur
    JOIN public."Role" r ON r.id = ur."roleId"
    WHERE ur."userId" = v_user
      AND ur."companyId" IS NOT NULL
      AND r.name IN ('owner', 'vendeur', 'vendeur_gare', 'chauffeur')
    ORDER BY
      CASE r.name
        WHEN 'owner' THEN 1
        WHEN 'vendeur' THEN 2
        WHEN 'vendeur_gare' THEN 3
        WHEN 'chauffeur' THEN 4
      END,
      ur.id
    LIMIT 1
  );
END;
$function$
;

-- ==== FUNCTION set_colis_autonome_photo ====
CREATE OR REPLACE FUNCTION public.set_colis_autonome_photo(p_colis_id uuid, p_photo_path text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_company_id uuid;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  SELECT company_id INTO v_company_id FROM public.colis_autonomes WHERE id = p_colis_id;
  IF v_company_id IS NULL THEN RAISE EXCEPTION 'Colis introuvable'; END IF;
  IF NOT public.is_company_role_user(v_user_id, v_company_id) THEN
    RAISE EXCEPTION 'Droits insuffisants';
  END IF;
  UPDATE public.colis_autonomes SET photo_path = p_photo_path, updated_at = now() WHERE id = p_colis_id;
END;
$function$
;

-- ==== FUNCTION station_cash_gare_company_id ====
CREATE OR REPLACE FUNCTION public.station_cash_gare_company_id(p_gare_id uuid)
 RETURNS uuid
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT g."companyId" FROM "Gares" g WHERE g.id = p_gare_id;
$function$
;

-- ==== FUNCTION submit_station_cash_reversal ====
CREATE OR REPLACE FUNCTION public.submit_station_cash_reversal(p_caisse_id uuid, p_montant_reverse integer)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
  v_caisse record;
  v_id uuid;
  v_montant integer;
  v_movement_id uuid;
BEGIN
  v_user_id := public.current_app_user_id();
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Utilisateur introuvable'; END IF;

  v_montant := COALESCE(p_montant_reverse, 0);
  IF v_montant <= 0 THEN RAISE EXCEPTION 'Montant reversement invalide'; END IF;

  SELECT * INTO v_caisse FROM caisses_gares WHERE id = p_caisse_id FOR UPDATE;
  IF v_caisse.id IS NULL THEN RAISE EXCEPTION 'Caisse introuvable'; END IF;

  IF v_caisse.gestionnaire_id <> v_user_id AND NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Reversement reserve au vendeur de la session';
  END IF;

  IF v_caisse.statut NOT IN ('ouverte', 'en_reversement') THEN
    RAISE EXCEPTION 'Session deja cloturee';
  END IF;

  INSERT INTO reversements_comptables (caisse_id, montant_reverse, statut_validation, soumis_par)
  VALUES (p_caisse_id, v_montant, 'en_attente', v_user_id)
  RETURNING id INTO v_id;

  -- Retrait immédiat du montant remis — voir commentaire de migration.
  v_movement_id := public.record_station_cash_movement(
    v_caisse.id,
    'reversement_comptable',
    v_montant,
    NULL,
    NULL,
    v_user_id,
    v_id,
    'Reversement soumis par le vendeur',
    'out'
  );

  RETURN jsonb_build_object(
    'id', v_id,
    'caisseId', p_caisse_id,
    'amount', v_montant,
    'status', 'en_attente',
    'movementId', v_movement_id,
    'currentBalance', (SELECT solde_especes_actuel FROM public.caisses_gares WHERE id = p_caisse_id)
  );
END;
$function$
;

-- ==== FUNCTION subscribe_to_colis_tracking ====
CREATE OR REPLACE FUNCTION public.subscribe_to_colis_tracking(p_colis_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT "id" INTO v_user_id FROM "Users" WHERE "auth_user_id" = auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Utilisateur introuvable';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM colis_autonomes WHERE id = p_colis_id) THEN
    RAISE EXCEPTION 'Colis introuvable';
  END IF;

  INSERT INTO "ColisTrackingSubscriptions" ("colisId", "userId")
  VALUES (p_colis_id, v_user_id)
  ON CONFLICT ("colisId", "userId") DO NOTHING;
END;
$function$
;

-- ==== FUNCTION sync_colis_autonome_from_module_d ====
CREATE OR REPLACE FUNCTION public.sync_colis_autonome_from_module_d()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE "Companies"
  SET colis_autonome_enabled = COALESCE(NEW."moduleD", false)
  WHERE id = NEW."companyId";
  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION tg_seed_company_colis_natures ====
CREATE OR REPLACE FUNCTION public.tg_seed_company_colis_natures()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  PERFORM public._seed_company_colis_natures(NEW.id);
  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION tg_seed_company_expense_categories ====
CREATE OR REPLACE FUNCTION public.tg_seed_company_expense_categories()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  PERFORM public._seed_company_expense_categories(NEW.id);
  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION tg_validate_gare_city_in_company_country ====
CREATE OR REPLACE FUNCTION public.tg_validate_gare_city_in_company_country()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  -- Restriction pays levée : une compagnie peut opérer (créer des gares)
  -- dans n'importe quel pays disponible sur la plateforme (itinéraires
  -- transfrontaliers). Le pays d'origine reste utilisé ailleurs pour la
  -- devise/paramètres par défaut de la compagnie, mais ne bloque plus la
  -- création de gares.
  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION trg_colis_autonomes_module_guard ====
CREATE OR REPLACE FUNCTION public.trg_colis_autonomes_module_guard()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  PERFORM public.assert_company_module(NEW.company_id, 'D');
  RETURN NEW;
END;
$function$
;

-- ==== FUNCTION unregister_device_token ====
CREATE OR REPLACE FUNCTION public.unregister_device_token(p_fcm_token character varying)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  DELETE FROM "DeviceTokens" WHERE "fcmToken" = p_fcm_token
    AND "userId" IN (SELECT "id" FROM "Users" WHERE "auth_user_id" = auth.uid());
END;
$function$
;

-- ==== FUNCTION unsubscribe_from_colis_tracking ====
CREATE OR REPLACE FUNCTION public.unsubscribe_from_colis_tracking(p_colis_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT "id" INTO v_user_id FROM "Users" WHERE "auth_user_id" = auth.uid();
  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  DELETE FROM "ColisTrackingSubscriptions"
  WHERE "colisId" = p_colis_id AND "userId" = v_user_id;
END;
$function$
;

-- ==== FUNCTION update_colis_autonome_statut ====
CREATE OR REPLACE FUNCTION public.update_colis_autonome_statut(p_colis_id uuid, p_new_statut text, p_bus_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid := public.current_app_user_id();
  v_colis public.colis_autonomes%ROWTYPE;
  v_company_name text;
  v_gare_depart text;
  v_gare_destination text;
  v_allowed boolean := false;
  v_message text;
  v_notify_recipients uuid[];
  v_notify_title text;
  v_notify_message text;
BEGIN
  IF v_user_id IS NULL THEN RAISE EXCEPTION 'Connexion requise'; END IF;
  SELECT * INTO v_colis FROM public.colis_autonomes WHERE id = p_colis_id;
  IF v_colis.id IS NULL THEN RAISE EXCEPTION 'Colis introuvable'; END IF;
  IF NOT public.is_company_role_user(v_user_id, v_colis.company_id) THEN RAISE EXCEPTION 'Droits insuffisants'; END IF;
  IF p_new_statut NOT IN ('enregistre', 'charge', 'arrive', 'livre') THEN RAISE EXCEPTION 'Statut invalide'; END IF;
  IF p_bus_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM "Bus" b WHERE b.id = p_bus_id AND b."companyId" = v_colis.company_id
  ) THEN
    RAISE EXCEPTION 'Bus invalide';
  END IF;

  IF v_colis.statut_colis = 'enregistre' AND p_new_statut = 'charge' THEN
    PERFORM public._assert_lot_access(v_colis.company_id, v_colis.gare_depart_id, ARRAY['chargeur_gare']);
  ELSIF v_colis.statut_colis = 'charge' AND p_new_statut = 'arrive' THEN
    PERFORM public._assert_lot_access(v_colis.company_id, v_colis.gare_destination_id, ARRAY['distributeur_gare']);
  END IF;

  v_allowed := CASE
    WHEN v_colis.statut_colis = 'enregistre' AND p_new_statut = 'charge' THEN true
    WHEN v_colis.statut_colis = 'charge' AND p_new_statut = 'arrive' THEN true
    WHEN v_colis.statut_colis = 'arrive' AND p_new_statut = 'livre' THEN true
    WHEN p_new_statut = v_colis.statut_colis THEN true
    ELSE false
  END;
  IF NOT v_allowed THEN RAISE EXCEPTION 'Transition non autorisee: % -> %', v_colis.statut_colis, p_new_statut; END IF;
  UPDATE public.colis_autonomes
  SET statut_colis = p_new_statut,
      bus_id = COALESCE(p_bus_id, bus_id),
      updated_at = now()
  WHERE id = p_colis_id;
  SELECT c.name, gd.name, gdest.name
  INTO v_company_name, v_gare_depart, v_gare_destination
  FROM "Companies" c
  JOIN "Gares" gd ON gd.id = v_colis.gare_depart_id
  JOIN "Gares" gdest ON gdest.id = v_colis.gare_destination_id
  WHERE c.id = v_colis.company_id;
  v_message := public.build_colis_sms_message(p_new_statut, p_colis_id, v_company_name, v_gare_depart, v_gare_destination);

  IF p_new_statut <> v_colis.statut_colis THEN
    v_notify_recipients := public._colis_notification_recipients(
      v_colis.company_id, v_colis.gare_depart_id, v_colis.gare_destination_id, v_user_id
    );
    v_notify_title := 'Colis mis à jour';
    v_notify_message := format('%s → %s : %s → %s', v_gare_depart, v_gare_destination, v_colis.statut_colis, p_new_statut);
    PERFORM public._create_colis_notifications(
      v_notify_recipients, 'colis_statut', v_notify_title, v_notify_message,
      jsonb_build_object('colisId', p_colis_id, 'companyId', v_colis.company_id, 'statut', p_new_statut)
    );
  ELSE
    v_notify_recipients := ARRAY[]::uuid[];
  END IF;

  RETURN jsonb_build_object(
    'id', p_colis_id,
    'statutColis', p_new_statut,
    'sms', public.build_colis_sms_payload(
      v_colis.company_id,
      p_new_statut,
      v_message,
      v_colis.telephone_expediteur,
      v_colis.telephone_destinataire
    ),
    'notifyRecipients', to_jsonb(v_notify_recipients),
    'notifyTitle', v_notify_title,
    'notifyMessage', v_notify_message
  );
END;
$function$
;

-- ==== FUNCTION validate_user_role_assignment ====
CREATE OR REPLACE FUNCTION public.validate_user_role_assignment()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_scope varchar;
  v_role_name varchar;
BEGIN
  SELECT r.scope, r.name INTO v_scope, v_role_name
  FROM public."Role" r WHERE r.id = NEW."roleId";

  IF v_scope IS NULL THEN
    RAISE EXCEPTION 'Rôle introuvable : %', NEW."roleId";
  END IF;

  IF v_scope = 'platform' AND NEW."companyId" IS NOT NULL THEN
    RAISE EXCEPTION 'Rôle plateforme "%" : companyId doit être NULL', v_role_name;
  END IF;

  IF v_scope = 'company' AND NEW."companyId" IS NULL THEN
    RAISE EXCEPTION 'Rôle compagnie "%" : companyId est obligatoire', v_role_name;
  END IF;

  IF v_role_name = 'admin_pays' AND NEW."countryId" IS NULL THEN
    RAISE EXCEPTION 'admin_pays requiert un countryId';
  END IF;

  IF v_scope = 'platform' AND v_role_name <> 'admin_pays' AND NEW."countryId" IS NOT NULL THEN
    RAISE EXCEPTION 'Rôle "%" : countryId doit être NULL', v_role_name;
  END IF;

  IF public._is_gare_scoped_role(v_role_name) AND NEW."gareId" IS NULL THEN
    RAISE EXCEPTION 'Rôle gare "%" : gareId est obligatoire', v_role_name;
  END IF;

  IF NEW."gareId" IS NOT NULL AND NOT public._is_gare_scoped_role(v_role_name) THEN
    RAISE EXCEPTION 'Seuls les rôles gare peuvent avoir un gareId (rôle "%")', v_role_name;
  END IF;

  RETURN NEW;
END;
$function$
;

-- ============================= TRIGGERS =============================

-- ==== TRIGGER colis_autonomes_module_guard ON "colis_autonomes" ====
DROP TRIGGER IF EXISTS colis_autonomes_module_guard ON "colis_autonomes";
CREATE TRIGGER colis_autonomes_module_guard BEFORE INSERT ON public.colis_autonomes FOR EACH ROW EXECUTE FUNCTION trg_colis_autonomes_module_guard();

-- ==== TRIGGER colis_numero_recu_trg ON "colis_autonomes" ====
DROP TRIGGER IF EXISTS colis_numero_recu_trg ON "colis_autonomes";
CREATE TRIGGER colis_numero_recu_trg BEFORE INSERT ON public.colis_autonomes FOR EACH ROW EXECUTE FUNCTION assign_colis_numero_recu();

-- ==== TRIGGER companies_seed_colis_natures ON "Companies" ====
DROP TRIGGER IF EXISTS companies_seed_colis_natures ON "Companies";
CREATE TRIGGER companies_seed_colis_natures AFTER INSERT ON public."Companies" FOR EACH ROW EXECUTE FUNCTION tg_seed_company_colis_natures();

-- ==== TRIGGER companies_seed_expense_categories ON "Companies" ====
DROP TRIGGER IF EXISTS companies_seed_expense_categories ON "Companies";
CREATE TRIGGER companies_seed_expense_categories AFTER INSERT ON public."Companies" FOR EACH ROW EXECUTE FUNCTION tg_seed_company_expense_categories();

-- ==== TRIGGER gares_validate_city_country ON "Gares" ====
DROP TRIGGER IF EXISTS gares_validate_city_country ON "Gares";
CREATE TRIGGER gares_validate_city_country BEFORE INSERT OR UPDATE OF "cityId", "companyId" ON public."Gares" FOR EACH ROW EXECUTE FUNCTION tg_validate_gare_city_in_company_country();

-- ==== TRIGGER trg_single_admin_pays_per_country ON "UserRoles" ====
DROP TRIGGER IF EXISTS trg_single_admin_pays_per_country ON "UserRoles";
CREATE TRIGGER trg_single_admin_pays_per_country BEFORE INSERT OR UPDATE OF "roleId", "countryId", "userId" ON public."UserRoles" FOR EACH ROW EXECUTE FUNCTION enforce_single_admin_pays_per_country();

-- ==== TRIGGER trg_sync_colis_module_d ON "CompanyFeatureModules" ====
DROP TRIGGER IF EXISTS trg_sync_colis_module_d ON "CompanyFeatureModules";
CREATE TRIGGER trg_sync_colis_module_d AFTER INSERT OR UPDATE OF "moduleD" ON public."CompanyFeatureModules" FOR EACH ROW EXECUTE FUNCTION sync_colis_autonome_from_module_d();

-- ==== TRIGGER user_roles_assignment_check ON "UserRoles" ====
DROP TRIGGER IF EXISTS user_roles_assignment_check ON "UserRoles";
CREATE TRIGGER user_roles_assignment_check BEFORE INSERT OR UPDATE ON public."UserRoles" FOR EACH ROW EXECUTE FUNCTION validate_user_role_assignment();
